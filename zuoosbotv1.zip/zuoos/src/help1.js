const help1 = (prefix) => {

	return `༺[𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆ 🙈]༻
       ═══════𖠇═══════𖠇═══════
        *MENU 1 ,༺𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆🙈༻*
       ═══════𖠇═══════𖠇═══════
   
       
➸ *${prefix}tagall1*
➸ *${prefix}tagall2*
➸ *${prefix}loli*
➸ *${prefix}loli1*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}meme*
➸ *${prefix}lofi*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}ts (texto que deseja transmitir)*

╔═══════════════════════
     𖤍ϟƵɄØØ$ϟ𖤍* 🐊/̷🚩
     DUVIDAS? 👇
   wa.me/5563992674217
╚═══════════════════════
Fale comigo antes de usat o bot!✨`

}
exports.help1 = help1



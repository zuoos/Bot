const help = (prefix) => {

	return`

	 *════𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩 ∆Bot∆════*

➩ Prefix:  *「${prefix}」*
➩ Status: *「Online🐒」*

       ╔════𖠇════╗
         *༺[Stickers 🐒]༻*
       ╚════𖠇════╝
      
➩ Comando : *${prefix}stiker* ou *${prefix}sticker*
➩ resultado de uso : converter imagem/gif/vídeo em adesivo
➩ modo de uso : responder imagem/gif/video ou enviar imagem/gif/video com a legenda \n
➩ Comando : *${prefix}tstiker nobg* ou *${prefix}tsticker nobg*
➩ resultado de uso : converter imagem em adesivo removendo o fundo
➩ modo de uso : responder imagem ou enviar imagem com a legenda \n
➩ Comando : *${prefix}toimg*
➩ resultado de uso : converter adesivo em imagem
➩ modo de uso : responder adesivo com a legenda toimg\n

      ╔════════𖠇════════╗
          *༺[OUTRAS PARADA AE...🙈]༻* 
      ╚════════𖠇════════╝
       
➩ Comando : *${prefix}meme*
➩ resultado de uso : mandar imagens aleatórias de memes 😂👍🏻 [inglês]
➩ modo de uso : basta emviar o comando\n

➩ Comando : *${prefix}gtts*
➩ resultado de uso : converter texto em fala/áudio
➩ modo de uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja Onii-chan*\n
➩ Comando : *${prefix}loli*
➩ resultado de uso : mandar imagens aleatórias de loli
➩ modo de uso : basta enviar o comando\n
➩ Comando : *${prefix}nsfwloli*
➩ resultado de uso : mandar imagens aleatórias de nsfw loli
➩ modo de uso : basta enviar o comando\n
➩ Comando : *${prefix}ocr*
➩ resultado de uso : pegar o texto da foto e lhe enviar
➩ modo de uso : responder imagem ou enviar mensagem com legenda\n
➩ Comando : *${prefix}wait*
➩ resultado de uso : pesquisar sobre o anime por imagem [ Que anime é esse ]
➩ modo de uso : responder imagem ou enviar imagem com legenda\n

       ╔════𖠇════╗
          *༺[GROUP🙈]༻*
       ╚════𖠇════╝
      
➩ Comando : *${prefix}linkgroup*
➩ resultado de uso : enviar o link do grupo
➩ modo de uso : basta enviar o comando\n
➩ Comando : *${prefix}tagall*
➩ resultado de uso : marcar todos os membros do grupo, incluindo administradores
➩ modo de uso : basta enviar o comando\n
➩ aviso! : Você precisa ser administrador do grupo\n
➩ Comando : *${prefix}add*
➩ resultado de uso : adicionar membro ao grupo
➩ modo de uso : *${prefix}adicionar 5585xxxxx*\n
➩ aviso! : o bot precisa ser admin!\n
➩ Comando : *${prefix}kick*
➩ resultado de uso : remover membros do grupo
➩ modo de uso : *${prefix}kick e o @da pessoa*\n
➩ aviso! : Você precisa ser admin e o bot também
➩ Comando : *${prefix}promote*
➩ resultado de uso : tornar membro do grupo um administrador
➩ modo de uso : *${prefix}promote e o @da pessoa*\n
➩ aviso! : Você precisa ser admin e o bot também
➩ Comando : *${prefix}demote*
➩ resultado de uso : tornar o administrador um membro comum
➩ modo de uso : *${prefix}demote e o @da pessoa*\n
➩ aviso! : Você precisa ser admin e o bot também
➩ Comando : *${prefix}setprefix*
➩ resultado de uso : alterar o prefixo do bot
➩ modo de uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➩ aviso! : Usado somente pelo proprietário do bot\n

       
       *༺[𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆ 🙈]༻*
                     

➩ *${prefix}help* 
    

╔════════𖠇═══════╗
      *Dono: 𖤍ϟƵɄØØ$ϟ𖤍* 🐊/̷🚩
      *Quer falar comigo? 👇*
       Wa.me/5563992674217
╚════════𖠇═══════╝`
}

exports.help1 = help








const help = (prefix) => {
	return `*════𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆════*


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online ✓」*

     ╔════𖠇════╗
      *༺[Stickers 🐒]༻*
     ╚════𖠇════╝
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda\n
➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda/n
➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta\n

    ╔════════𖠇════════╗
       *༺[OUTRAS PARADA AE...🙈]༻* 
    ╚════════𖠇════════╝
       
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta emviar o comando\n

➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja On2-chan*\n
➸ Comando : *${prefix}loli*
➸ útil em : mandar imagens aleatórias de loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}nsfwloli*
➸ útil em : mandar imagens aleatórias de nsfw loli
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda\n
➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : responder imagem ou enviar imagem com legenda\n

    ╔════𖠇════╗
      *༺[GROUP🙈]༻*
    ╚════𖠇════╝
      
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando\n
➸ Comando : *${prefix}tagall*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando\n
➸ Nota : Você precisa ser administrador do grupo\n
➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add 5585xxxxx*\n
➸ Nota : o bot precisa ser admin!\n
➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*\n
➸ Nota : Você precisa ser admin e o bot também
➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot\n

       ════════∆══════════
        *MENU 1 ༺𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩༻*
       ════════∆══════════   

➸ *${prefix}help1* 🐒
    

╔═══════════════════════
     𖤍ϟƵɄØØ$ϟ𖤍* 🐊/̷🚩
     Dono: 👇
  Wa.me/5563992674217
╚═══════════════════════
Fale comigo antes de usar o bot!✨`
}

exports.help = help








const help = (prefix) => {
	return `*════𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆════*


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online ✓」*

     ╔════𖠇════╗
       *༺[Stickers 🐒]༻*
     ╚════𖠇════╝
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda apena até 9 segundos

➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta

    ╔════════𖠇════════╗
        *༺[OUTRAS PARADA AE...🙈]༻* 
    ╚════════𖠇════════╝

➸ Comando : *${prefix}blocklist*
➸ útil em : mostrar contatos bloqueados pelo Bot
➸ uso : basta enviar o comando

➸ Comando : *${prefix}updatinfor*
➸ útil em : mandar uma nota de atualização do bot
➸ uso : basta enviar o comando
              
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta enviar o comando

➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja Onii-chan*
➸ Comandos de idioma do bot : 

➸ af = Afrikaans
➸ sq = Albanian
➸ ar = Arabic
➸ hy = Armenian
➸ ca = Catalan
➸ zh = Chinese
➸ zh-cn = Chinese (Mandarin/China)
➸ zh-tw = Chinese (Mandarin/Taiwan)
➸ zh-yue = Chinese (Cantonese)
➸ hr = Croatian
➸ cs = Czech
➸ da = Danish
➸ nl = Dutch
➸ en = English
➸ en-au = English (Australia)
➸ en-uk = English (United Kingdom)
➸ en-us = English (United States)
➸ eo = Esperanto
➸ fi = Finnish
➸ fr = French
➸ de = German
➸ el = Greek
➸ ht = Haitian Creole
➸ hi = Hindi
➸ hu = Hungarian
➸ is = Icelandic
➸ id = Indonesian
➸ it = Italian
➸ ja = Japanese
➸ ko = Korean
➸ la = Latin
➸ lv = Latvian
➸ mk = Macedonian
➸ no = Norwegian
➸ pl = Polish
➸ pt = Portuguese
➸ pt-br = Portuguese (Brazil)
➸ ro = Romanian
➸ ru = Russian
➸ sr = Serbian
➸ sk = Slovak
➸ es = Spanish
➸ es-es = Spanish (Spain)
➸ es-us = Spanish (United States)
➸ sw = Swahili
➸ sv = Swedish
➸ ta = Tamil
➸ th = Thai
➸ tr = Turkish
➸ vi = Vietnamese
➸ cy = Welsh

➸ Comando : *${prefix}loli*
➸ útil em : Mandar imagens aleatórias de loli
➸ uso : Basta enviar o comando

➸ Comando : *${prefix}nsfwloli*
➸ útil em : Mandar imagens aleatórias de nsfw loli
➸ uso : Basta enviar o comando

➸ Comando : *${prefix}ocr*
➸ útil em : Pegar o texto da foto e lhe enviar
➸ uso : Responder imagem ou enviar mensagem com legenda

➸ Comando : *${prefix}wait*
➸ útil em : Pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : Responder imagem ou enviar imagem com legenda

➸ Comando : *${prefix}lofi*
➸ útil em : Manda o link de lives de lofi
➸ uso : Basta enviar o comando

    ╔════𖠇════╗
       *༺[GROUP🙈]༻*
    ╚════𖠇════╝
    
➸ Comando : *${prefix}kitar*
➸ útil em : Fazer o bot sair do grupo
➸ uso : Você precisa ser administrador do grupo
 
➸ Comando : *${prefixhash*
➸ útil em : Mandar uma mensagem de jogo da velha
➸ uso : basta enviar o comando 
      
➸ Comando : *${prefix}listadmins*
➸ útil em : mostrar admins do grupo em uma lista
➸ uso : basta enviar o comando
   
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando

➸ Comando : *${prefix}marcar*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando
➸ Nota : Você precisa ser administrador do grupo

➸ Comando : *${prefix}add*
➸ útil em : adicionar membros ao grupo
➸ uso : *${prefix}add 5585xxxxx*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}ban*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @ da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}promover*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promover e o @ da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}rebaixar*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}rebaixar e o @ da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}welcome*
➸ útil em : ativa uma mensagem de boas vindas ao grupo
➸ uso : *${prefix}welcome 1 para ativar, 0 pra desativar 
➸ Nota : Usado somente em grupos 

    ╔═══════𖠇══════╗
      *༺[Comandos para Dono]༻*
    ╚═══════𖠇══════╝  

➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot

➸ Comando : *${prefix}limpar*
➸ útil em : limpa os chats do bot
➸ uso : basta enviar o comando   
➸ Nota : Usado somente pelo proprietário do bot
  
➸ Comando : *${prefix}ts*
➸ útil em : manda uma mensagem em transmissão
➸ uso : *${prefix}ts [text]*\nexemplo : *${prefix}ts Zuoos Brabo*\n
➸ Nota : Usado somente pelo proprietário do bot
     
       ════════∆══════════
           *MENU  ༺𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩༻*
       ════════∆══════════   

➸ *${prefix}help* 🐒
    

╔══════════════════════
     Dono: 𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩
 
     Para falar comigo use  *${prefix}dono*
╚══════════════════════
Fale comigo antes de usar o bot!✨`
}

exports.help = help








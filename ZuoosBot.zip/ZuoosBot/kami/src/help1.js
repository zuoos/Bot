﻿const help1 = (prefix) => {

	return `╔╦══•ᬊ᭄✞𝑲𝑨𝑴𝑰✰𝑺𝑨𝑴𝑨✞𖥨ํ∘̥⃟⸽⃟🌹•══╦╗
       • ────── ✾ ────── •
       *MENU 1 DA KAMI*【✔】
       • ────── ✾ ────── •   
       
➸ *${prefix}tagall1*
➸ *${prefix}tagall2*
➸ *${prefix}loli*
➸ *${prefix}loli1*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}akeno*
➸ *${prefix}meme*
➸ *${prefix}lofi*
➸ *${prefix}nsfwloli*
➸ *${prefix}reislin*
➸ *${prefix}limpar*
➸ *${prefix}ts (texto que deseja transmitir)*

╔═══════════════════════
     ᬊ᭄✞𝑲𝑨𝑴𝑰✰𝑺𝑨𝑴𝑨✞𖥨ํ∘̥⃟⸽⃟🌹
     DUVIDAS? 👇
  Wa.me/5561992827345
╚═══════════════════════
𝐀𝐆𝐑𝐀𝐃𝐄𝐂𝐎 𝐏𝐎𝐑 𝐌𝐄 𝐔𝐒𝐀𝐑!✨`

}
exports.help1 = help1



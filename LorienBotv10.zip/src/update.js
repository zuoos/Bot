const update = (prefix) => {
	return `_*[⇨         ᯽Lorien Bot WhatsApp ᯽         ⇦]*_
	
	
	᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Bot feito por : ⸸Zuoos⸸*_
_*➤ Numero do criador : wa.me/556392674217*_
_*➤ Versão do Bot : V2.0*_
_*➤ Para saber sobre a att escreva : [ ${prefix}update ]*_
_*➤ Meu canal : https://youtube.com/c/ZuoosEditsYt*_
_*➤ Instagram : @zuoos.amp*_
_*➤ Bot para grupos, não use no privado*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━━━━━━━━━┃
    _*⏣ Notas de atualização : 𝐋𝐨𝐫𝐢𝐞𝐧 𝐛𝐨𝐭 ⏣*_
┃━━━━━━━━━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ O menu do Bot foi mudado*_

_*➤ Comandos foram adicionados :*_
_*⟐ Jogo ⟐*_
_*⟐ Meme ⟐*_
_*⟐ Wall ⟐*_
_*⟐ Plaquinha ⟐*_
_*⟐ Bug ⟐*_
_*⟐ Idiomas ⟐*_
_*⟐ Att ⟐*_
_*⟐ Arquivar ⟐*_
_*⟐ Setnome ⟐*_
_*⟐ Setfoto ⟐*_
_*⟐ Troll ⟐*_
_*⟐ Meee ⟐*_
_*⟐ Rapaa ⟐*_
_*⟐ Xxx ⟐*_
_*⟐ Gfoto ⟐*_
_*⟐ Gnome ⟐*_
_*⟐ Porr ⟐*_
_*⟐ Noia ⟐*_
_*⟐ Falsidade ⟐*_
_*⟐ Whatsapp2 ⟐*_

_*➤ Adicionado mais aplicativos em [ ${prefix}apps ] *_

_*➤ Adicionado comandos de voz*_

_*➤ Mudanças em alguns comandos *_
_*⟐ Welcome = Bv ⟐*_
_*⟐ Fotogp = Gfoto ⟐*_
_*⟐ Nomegp = Gnome ⟐*_
_*⟐ Blocklist = Bloqueados ⟐*_
_*⟐ Sticker = Figu ⟐*_
_*⟐ Listadmins = admins ⟐*_

᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Versão atual : V2.0*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽
`
}

exports.update = update








const apps = () => { 
	return `
	_*Mods de aplicativos e jogos*_
	
_*Veja o menu de apps e mods :*_


                  _*APPS E JOGOS*_
                 
                 
_*⟐ VivaCut (PRO)⟐*_                  
https://suaurl.com/b8c459

_*⟐ WhatsApp base quinaria (Base)⟐*_                  
 https://suaurl.com/35d7d5               
                     
_*⟐ LuckPath (PRO)⟐*_                 
https://suaurl.com/ad4167           
       
_*⟐ Netflix Gratis (PRO)⟐*_                  
https://suaurl.com/cb45c3           
       
 _*⟐ ApkEditor (PRO)⟐*_                 
https://suaurl.com/a87b73            
      
_*⟐ TextNow (PRO)⟐*_
https://suaurl.com/718aa1
                                                      
_*⟐ GTA San (Original)⟐*_ 
https://suaurl.com/065443

_*⟐bully (Original)⟐*_ 
https://suaurl.com/960030

_*⟐ InstaProMod(PRO)⟐*_ 
https://suaurl.com/e69e22

_*⟐ PicsArtPro (PRO)⟐*_ 
https://suaurl.com/14acf3

_*⟐ PixellabMod (PRO)⟐*_ 
https://suaurl.com/f7d6d2
                 
_*⟐ spotify Premium (PRO)⟐*_ 
https://suaurl.com/0ee335

_*⟐ PowerDirector V9.0.0 (PRO)⟐*_ 
https://suaurl.com/b958fd

_*⟐ Teraria mobile V1.4.0.5.2.1 (Original)⟐*_
https://suaurl.com/460ecb

_*⟐ AutoResponder (PRO)⟐*_
https://suaurl.com/e6e5b1

_*⟐ Minecraft (Original)⟐*_
https://suaurl.com/4c318c

_*⟐ KineMaster (PRO)⟐*_
https://suaurl.com/5740f3

_*⟐ KineMaster Diamond (MOD)⟐*_
https://suaurl.com/dd300a

_*⟐ KineMaster Ruby (MOD)⟐*_
https://suaurl.com/984f89

_*⟐ Adobe Photoshop (Original)⟐*_
https://suaurl.com/bc1e3a

_*⟐ Alight Motion V3.6.1 (PRO)⟐*_ 
https://suaurl.com/6406d5

_*⟐ Alight Motion V3.1.4 (PRO)⟐*_ 
https://suaurl.com/f0f964

_*⟐ Avee Player (PRO)⟐*_
https://suaurl.com/2ae954

_*⟐ Pixellab (PRO)⟐*_
https://suaurl.com/c12222

_*⟐ Inshot (PRO)⟐*_
https://suaurl.com/b17439

_*⟐ WavePad (PRO)⟐*_
https://suaurl.com/0792b7

_*⟐ Vimage (PRO)⟐*_
https://suaurl.com/28051e

_*⟐ Zeotropic (PRO)⟐*_
https://suaurl.com/98ff11

_*⟐ 90s (PRO)⟐*_
https://suaurl.com/d58f12


_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.apps = apps
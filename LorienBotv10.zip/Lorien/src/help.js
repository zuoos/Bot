const help = (prefix) => {
	return `_*[⇨         ᯽Lorien Bot WhatsApp ᯽         ⇦]*_
	
	
᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Bot feito por : ⸸Zuoos⸸*_
_*➤ Numero do criador : wa.me/556392674217*_
_*➤ Versão do Bot : V2.0*_
_*➤ Para saber sobre a att escreva : [ ${prefix}update ]*_
_*➤ Meu canal : https://youtube.com/c/ZuoosEditsYt*_
_*➤ Instagram : @zuoos.amp*_
_*➤ Bot para grupos, não use no privado*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━━┃
    _*⏣ Regras : 𝐋𝐨𝐫𝐢𝐞𝐧 𝐛𝐨𝐭 ⏣*_
┃━━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Não Floodem comandos*_

_*➤ Não seja doentio, use o bot de maneira certa*_

_*➤ Se quiser por em seu grupo, fale com o Zuoos*_

_*➤ Erros ou bugs no bot reporte ao Zuoos*_

_*⏣ Para reportar bugs ou dar sugestoes escreva :*_

_*➤ [ {$prefix}bug 'sua mensagem' ]*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━━━┃
  _*➤ ⏣ Figurinhas/Stickers ⏣*_
┃━━━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Figu*_
_*⏣ Função : Faz figurinhas de foto/gif/video ⏣*_

_*➤ Comando : Toimg*_
_*⏣ Função : Converte figurinhas em fotos ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━┃
  _*➤ ⏣ Grupos ⏣*_
┃━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Gfoto*_
_*⏣ Função : Muda a foto do grupo ⏣*_

_*➤ Comando : Gnome*_
_*⏣ Função : Muda nome do grupo ⏣*_

_*➤ Comando : Marcar*_
_*⏣ Função : Marca todos os membros do grupo ⏣*_

_*➤ Comando : Bv*_
_*⏣ Função : Da boas vindas a quem entra no grupo ⏣*_

_*➤ Comando : Ban*_
_*⏣ Função : Bane membros do grupo ⏣*_

_*➤ Comando : Add*_
_*⏣ Função : Adiciona membros no grupo ⏣*_

_*➤ Comando : Promover*_
_*⏣ Função : Promove membros a admins ⏣*_

_*➤ Comando : Rebaixar*_
_*⏣ Função : Rebaixa admins a membros ⏣*_

_*➤ Comando : Fechargp*_
_*⏣ Função : Fecha o grupo ⏣*_

_*➤ Comando : Abrirgp*_
_*⏣ Função : Abre o grupo ⏣*_

_*➤ Comando : Linkgp*_
_*⏣ Função : Manda o link de convite do grupo ⏣*_

_*➤ Comando : Kitar*_
_*⏣ Função : Faz o bot sair do grupo ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━┃
  _*➤ ⏣ Fotos/Imagens ⏣*_
┃━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Plaquinha*_
_*⏣ Função : Faz uma plaquinha na raba ⏣*_

_*➤ Comando : Wall*_
_*⏣ Função : Manda alguns wallpapers ⏣*_

_*➤ Comando : Meme*_
_*⏣ Função : Manda memes em inglês ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━━━━┃
  _*➤ ⏣ Entreterimento/Funções ⏣*_
┃━━━━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Hash*_
_*⏣ Função : Manda um jogo da velha ⏣*_

_*➤ Comando : Att*_
_*⏣ Função : Exibe uma nota de atualização do bot ⏣*_

_*➤ Comando : Jogo*_
_*⏣ Função : Faz uma continha de matemática ⏣*_

_*➤ Comando : Wait*_
_*⏣ Função : Descobre nome de animes por fotos ⏣*_

_*➤ Comando : Gtts*_
_*⏣ Função : Faz o bot mandar um áudio ⏣*_

_*➤ Comando : Destrava*_
_*⏣ Função : Manda uma destrava ⏣*_

_*➤ Comando : Gado*_
_*⏣ Função : Manda sua porcentagem de gadisse ⏣*_

_*➤ Comando : Feiura*_
_*⏣ Função : Manda sua porcentagem de feiura ⏣*_

_*➤ Comando : Beleza*_
_*⏣ Função : Manda sua porcentagem de beleza ⏣*_

_*➤ Comando : Wame*_
_*⏣ Função : Manda seu link do whatsapp ⏣*_

_*➤ Comando : Admins*_
_*⏣ Função : Exibe os admins do grupo ⏣*_

_*➤ Comando : Bloqueados*_
_*⏣ Função :Exibe os numeros bloqueados pelo bot ⏣*_

_*➤ Comando : Ocr*_
_*⏣ Função : Retira texto de imagens ⏣*_

_*➤ Comando : Bug*_
_*⏣ Função : Reporta ao dono uma mensagem ⏣*_

_*➤ Comando : Dono*_
_*⏣ Função : Exibe informações sobre o dono ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━┃
  _*➤ ⏣ Criador/Owner ⏣*_
┃━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Tm*_
_*⏣ Função : Faz uma transmissão nos chats do bot ⏣*_

_*➤ Comando : Arquivar*_
_*⏣ Função : Remove todos do grupo ⏣*_

_*➤ Comando : Setname*_
_*⏣ Função : Muda nome do bot ⏣*_

_*➤ Comando : Setfoto*_
_*⏣ Função : Muda foto do bot ⏣*_

_*➤ Comando : Clone*_
_*⏣ Função : Rouba fotos de perfil das pessoas ⏣*_

_*➤ Comando : Mudarprefix*_
_*⏣ Função : Muda o prefixo do bot ⏣*_

_*➤ Comando : Gpess*_
_*⏣ Função : Nada a comentar ⏣*_

_*➤ Comando : Gcp*_
_*⏣ Função : Nada a comentar ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━┃
  _*➤ ⏣ Menus ⏣*_
┃━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Idiomas*_
_*⏣ Função : Exibe idiomas para o comando [ gtts ] ⏣*_

_*➤ Comando : Apps*_
_*⏣ Função : Exibe uma Lista de apps Pros e Premiums ⏣*_

_*➤ Comando : Menu*_
_*⏣ Função : Exibe o menu do bot ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


┃━━━━━━━━━━┃
  _*➤ ⏣ Audios/Mp3 ⏣*_
┃━━━━━━━━━━┃


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Comando : Troll*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Meee*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Xxx*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Whatsapp2*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Rapaa*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Porrr*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Noia*_
_*⏣ Função : Manda um áudio ⏣*_

_*➤ Comando : Pdp*_
_*⏣ Função : Manda um áudio ⏣*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


᯽━━━━━━━━━⟐᪥⟐━━━━━━━━━᯽
_*➤ Bot feito por : ⸸Zuoos⸸*_
_*➤ Numero do criador : wa.me/556392674217*_
_*➤ Versão do Bot : V2.0*_
_*➤ Meu canal : https://youtube.com/c/ZuoosEditsYt*_
᯽━━━━━━━━━⟐᪥⟐━━━━━━━━━᯽


᯽━━━━━━━━━⟐᪥⟐━━━━━━━━━᯽
_*᪣ Atualizações em breve!!! ᪣*_
᯽━━━━━━━━━⟐᪥⟐━━━━━━━━━᯽
`
}

exports.help = help
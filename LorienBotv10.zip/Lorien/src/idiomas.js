const idiomas = (prefix) => {
	return `_*⟐ Linguas Para o comando ⟐*_ 
            
_*⟐ Para o uso das linguas no comando, use-as assim : ⟐*_ 
        
_*⟐ Exemplo : [ ${prefix}gtts pt Zuoos  ] : ⟐*_ 



_*⟐ Linguas Para o comando [ ${prefix}gtts ] : ⟐*_ 

⟐ af = Afrikaans
⟐ sq = Albanian
⟐ ar = Arabic
⟐ hy = Armenian
⟐ ca = Catalan
⟐ zh = Chinese
⟐ hr = Croatian
⟐ cs = Czech
⟐ da = Danish
⟐ nl = Dutch
⟐ en = English
⟐ eo = Esperanto
⟐ fi = Finnish
⟐ fr = French
⟐ de = German
⟐ el = Greek
⟐ ht = Haitian Creole
⟐ hi = Hindi
⟐ hu = Hungarian
⟐ is = Icelandic
⟐ id = Indonesian
⟐ it = Italian
⟐ ja = Japanese
⟐ ko = Korean
⟐ la = Latin
⟐ lv = Latvian
⟐ mk = Macedonian
⟐ no = Norwegian
⟐ pl = Polish
⟐ pt = Portuguese
⟐ ro = Romanian
⟐ ru = Russian
⟐ sr = Serbian
⟐ sk = Slovak
⟐ es = Spanish
⟐ sw = Swahili
⟐ sv = Swedish
⟐ ta = Tamil
⟐ th = Thai
⟐ tr = Turkish
⟐ vi = Vietnamese
⟐ cy = Welsh

      _*⟐ Esses são os idiomas do bot ⟐*_ 
`
}

exports.idiomas = idiomas















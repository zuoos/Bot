const slot = (somtoy, somtoy2, somtoy3) => {
return `
━━━━━━━━━━━━
_*Será que você tem sorte?*_

      ➤  ${somtoy}
      ➤  ${somtoy2}
      ➤  ${somtoy3}

_*Mais sorte na próxima 👏🏻*_            
━━━━━━━━━━━━

`
}

exports.slot = slot

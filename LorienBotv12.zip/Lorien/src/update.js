const update = (prefix) => {
	return `_*[⇨         ᯽Lorien Bot WhatsApp ᯽         ⇦]*_
	
	
᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Bot feito por : ⸸Zuoos⸸*_
_*➤ Numero do criador : wa.me/556392674217*_
_*➤ Versão do Bot : V2.2*_
_*➤ Meu canal : https://youtube.com/c/ZuoosEditsYt*_
_*➤ Bot para grupos, não use no privado*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽

᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
┃━━━━━━━━━━━━━━━━━━┃
    _*⏣ Notas de atualização : 𝐋𝐨𝐫𝐢𝐞𝐧 𝐛𝐨𝐭 ⏣*_
┃━━━━━━━━━━━━━━━━━━┃
_*➤ Comandos adicionados :*_

_*⟐ Infogp ⟐*_ 
_*⟐ Apps2 ⟐*_
_*⟐ Bixo ⟐*_ 
_*⟐ Online ⟐*_ 
_*⟐ Wp ⟐*_ 
_*⟐ Loli ⟐*_ 
_*⟐ Neko ⟐*_ 
_*⟐ Shit ⟐*_ 
_*⟐ Cep ⟐*_ 
_*⟐ Chance ⟐*_ 
_*⟐ Ytmp4 ⟐*_ 
_*⟐ Perfil ⟐*_ 

_*➤ Comandos removidos :*_

_*⟐ Plaquinha ⟐*_ 

_*➤ Aplicativos foram adicionados em [ ${prefix}Apps2 ]*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽

᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Versão atual : V2.2*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽
`
}

exports.update = update








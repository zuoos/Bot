const imunes = () => { 
	return `_*[⇨         ᯽ WHATSAPPS IMUNES ᯽         ⇦]*_


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*⟐ MINATO V9 - ⟐*_ 
https://suaurl.com/f23374

_*⟐ YYGDRASIL AZUL - ⟐*_ 
https://suaurl.com/5fa5ff

_*⟐ BILLS V12 - ⟐*_ 
https://suaurl.com/17e1d6

_*⟐ TITAM V29 - ⟐*_ 
https://suaurl.com/b0bc1c

_*⟐ HIDRA AMARELO - ⟐*_ 
https://suaurl.com/148b8f

_*⟐ ELMO WAR 12 - ⟐*_ 
https://suaurl.com/148b8f

_*⟐ IMORTAL V17 - ⟐*_ 
https://suaurl.com/cf8583

_*⟐ BESTHYPE V1 - ⟐*_ 
https://suaurl.com/7bd406

_*⟐ ANJO WA GOLD - ⟐*_ 
https://suaurl.com/f30f0e

_*⟐ UNIVERSE - ⟐*_ 
https://suaurl.com/111a4e

_*⟐ STRAGE MILENARIO - ⟐*_ 
https://suaurl.com/be2a83

_*⟐ ACE PRIVATE - ⟐*_ 
https://suaurl.com/6d6ce7

_*⟐ ALIEN X ⟐*_ 
https://suaurl.com/912d6f

_*⟐ TISU V4 -  ⟐*_ 
https://suaurl.com/6981df

_*⟐ MAVERICK STYLE - ⟐*_ 
https://suaurl.com/0e13ae

_*⟐ SCOTZINN PRIVATE V2 - ⟐*_ 
https://suaurl.com/d527fb

_*⟐ BASE PRA TODOS ELES ⟐*_ 
https://suaurl.com/f45fd0

_*⟐ HIDRA TURNADO COM CONTADOR ⟐*_ 
https://suaurl.com/a3c6a3
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.imunes = imunes
const apps = () => { 
	return `_*[⇨         ᯽ APLICATIVOS/JOGOS᯽         ⇦]*_
                  
     
᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽                               
 _*⟐ MT Manage ⟐*_                  
https://suaurl.com/d1fba3
                                                                                                                               
_*⟐ Crunchyroll Premium ⟐*_                                                                                                             
https://suaurl.com/979d69
                                                                                                                                                
_*⟐ Avast Cleanup Pro ⟐*_                                                                                                                                                                                     
https://suaurl.com/199813
                                                                                                                                                                                                                        
_*⟐ Resso Premium ⟐*_                                                                                                                                                                                                                                                             
https://suaurl.com/7e2e5f

_*⟐ YouTube Music Premium ⟐*_ 
https://suaurl.com/3be3ec
                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
_*⟐ Deezer ⟐*_                     
https://suaurl.com/8e6d2c                      
                        
_*⟐ YouTube PRO ⟐*_                           
https://suaurl.com/085969
                           
_*⟐ Amazon Music ⟐*_                               
https://suaurl.com/f09ee4
                                  
_*⟐ The Sun origin Mod ⟐*_         
https://suaurl.com/ded7ee

_*⟐ VSCO ⟐*_ 
https://suaurl.com/cb7d71

_*⟐ Pack de transições After Efects ⟐*_                      
https://suaurl.com/1c7bd0                                      
                                                                                    
_*⟐ Vegas Pro 14 ⟐*_ 
https://suaurl.com/affcde                                    
                                        
_*⟐ After CC 2018 ⟐*_    
https://suaurl.com/b1a8b1              
                                                   
_*⟐ VivaCut ⟐*_                  
https://suaurl.com/b8c459
                     
_*⟐ LuckPath ⟐*_                 
https://suaurl.com/ad4167           
       
_*⟐ Netflix Gratis ⟐*_                  
https://suaurl.com/cb45c3           
       
 _*⟐ ApkEditor ⟐*_                 
https://suaurl.com/a87b73            
      
_*⟐ TextNow ⟐*_
https://suaurl.com/718aa1

_*⟐ NBA ⟐*_ 
https://suaurl.com/abda77                                                      
                                                                                                                                                                  
_*⟐ GTA San ⟐*_ 
https://suaurl.com/065443

_*⟐ GTA San Pc ⟐*_ 
https://suaurl.com/74a4cb

_*⟐bully ⟐*_ 
https://suaurl.com/960030

_*⟐ InstaProMod ⟐*_ 
https://suaurl.com/e69e22

_*⟐ PicsArtPro ⟐*_ 
https://suaurl.com/14acf3

_*⟐ PixellabMod ⟐*_ 
https://suaurl.com/f7d6d2
                 
_*⟐ spotify Premium ⟐*_ 
https://suaurl.com/0ee335

_*⟐ PowerDirector V9.0.0 ⟐*_ 
https://suaurl.com/b958fd

_*⟐ Teraria mobile V1.4.0.5.2.1 ⟐*_
https://suaurl.com/460ecb

_*⟐ AutoResponder ⟐*_
https://suaurl.com/e6e5b1

_*⟐ Minecraft ⟐*_
https://suaurl.com/4c318c

_*⟐ KineMaster ⟐*_
https://suaurl.com/5740f3

_*⟐ KineMaster Diamond ⟐*_
https://suaurl.com/dd300a

_*⟐ KineMaster Ruby ⟐*_
https://suaurl.com/984f89

_*⟐ Adobe Photoshop ⟐*_
https://suaurl.com/bc1e3a

_*⟐ Alight Motion V3.4.3 Suport Preset ⟐*_
https://suaurl.com/b6b50b


_*➤ Para ver mais apps digite 「 ${prefix}Apps2 」*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽

_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.apps = apps
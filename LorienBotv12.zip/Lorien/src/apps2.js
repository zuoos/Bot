const apps2 = () => { 
	return `_*[⇨         ᯽ APLICATIVOS/JOGOS᯽         ⇦]*_
                  
     
᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽                               
_*⟐ Alight Motion V3.6.2 Suport Xml ⟐*_
https://suaurl.com/14d164

_*⟐ Alight Motion V3.6.1⟐*_ 
https://suaurl.com/6406d5

_*⟐ Alight Motion V3.1.4 ⟐*_ 
https://suaurl.com/f0f964

_*⟐ Avee Player ⟐*_
https://suaurl.com/2ae954

_*⟐ Pixellab ⟐*_
https://suaurl.com/c12222

_*⟐ Inshot ⟐*_
https://suaurl.com/b17439

_*⟐ WavePad ⟐*_
https://suaurl.com/0792b7

_*⟐ Vimage ⟐*_
https://suaurl.com/28051e

_*⟐ Zeotropic ⟐*_
https://suaurl.com/98ff11

_*⟐ 90s ⟐*_
https://suaurl.com/d58f12
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽

_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.apps2 = apps2
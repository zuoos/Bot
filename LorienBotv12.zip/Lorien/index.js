const {
  WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange,
    MessageOptions,
    WALocationMessage,
    WA_MESSAGE_STUB_TYPES,
    ReconnectMode,
    ProxyAgent,
    waChatKey,
    mentionedJid,
    processTime,
} = require('@adiwajshing/baileys')
const { color, bgcolor } = require('./lib/color')
const { help } = require('./src/help')
const { imunes } = require('./src/imunes')
const { bases } = require('./src/bases')
const { idiomas } = require('./src/idiomas')
const { update } = require('./src/update')
const { apps } = require('./src/apps')
const { apps2 } = require('./src/apps2')
const { gcpf } = require('./src/gcpf')
const { gpessoa } = require('./src/gpessoa')
const { destrava } = require('./src/destrava')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const fs = require('fs')
const moment = require('moment-timezone')
const { exec } = require('child_process')
const kagApi = require('@kagchi/kag-api')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')
const imgbb = require('imgbb-uploader')
const lolis = require('lolis.life')
const crypto = require('crypto')
const loli = new lolis()
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./lib/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
const _registered = JSON.parse(fs.readFileSync('./lib/registered.json'));
const { slot } = require('./src/slot')
prefix = '.' 
blocked = []


//apikey
BarBarKey = prefix.BarBarKey;
vKey = prefix.Vhtearkey;
viKey = prefix.Vinzapi
meKey = prefix.Itsmeikyapi
lolKey = prefix.LolHumanKey


const getRegisteredRandomId = () => {
  return _registered[Math.floor(Math.random() * _registered.length)].id
}

const addRegisteredUser = (userid, sender, age, time, serials) => {
  const obj = {
id: userid,
name: sender,
age: age,
time: time,
serial: serials
  }
  _registered.push(obj)
  fs.writeFileSync('./lib/registered.json', JSON.stringify(_registered))
}

const createSerial = (size) => {
  return crypto.randomBytes(size).toString('hex').slice(0, size)
}

const checkRegisteredUser = (sender) => {
  let status = false
  Object.keys(_registered).forEach((i) => {
if (_registered[i].id === sender) {
  status = true
}
  })
  return status
}


/*const addATM = (sender) => {
  const obj = {
id: sender, uang: 0
  }
  uang.push(obj)
  fs.writeFileSync('./lib/uang.json',
JSON.stringify(uang))
}

const addKoinUser = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang += amount
fs.writeFileSync('./lib/uang.json', JSON.stringify(uang))
  }
}

const checkATMuser = (sender) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
return uang[position].uang
  }
}

const bayarLimit = (sender, amount) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit -= amount
fs.writeFileSync('./datauser/limit.json', JSON.stringify(_limit))
  }
}

const confirmATM = (sender, amount) => {
  let position = false
  Object.keys(uang).forEach((i) => {
if (uang[i].id === sender) {
  position = i
}
  })
  if (position !== false) {
uang[position].uang -= amount
fs.writeFileSync('./datauser/uang.json', JSON.stringify(uang))
  }
}

const limitAdd = (sender) => {
  let position = false
  Object.keys(_limit).forEach((i) => {
if (_limit[i].id == sender) {
  position = i
}
  })
  if (position !== false) {
_limit[position].limit += 1
fs.writeFileSync('./lib/limit.json', JSON.stringify(_limit))
  }
}
*/

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Hora ${pad(minutes)} Minuto ${pad(seconds)} Segundo`
}

async function starts() {
	const lorien = new WAConnection()
	lorien.logger.level = 'warn'
	console.log(banner.string)
	lorien.on('qr', () => {
		console.log(color('[','white'), color('!','red'), color(']','white'), color('Escaneia o codigo blz'))
	})

	fs.existsSync('./BarBar.json') && lorien.loadAuthInfo('./BarBar.json')
	lorien.on('connecting', () => {
		start('2', 'Conectando porra')
	})
	lorien.on('open', () => {
		success('2', 'conectado diabo')
	})
	await lorien.connect({timeoutMs: 30*1000})
  fs.writeFileSync('./BarBar.json', JSON.stringify(lorien.base64EncodedAuthInfo(), null, '\t'))

	lorien.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await lorien.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await lorien.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `_*OLA!!!*_ @${num.split('@')[0]}\n_*BEM VINDO AO GRUPO :*_ *${mdata.subject}* \n_*NAO SEJA GHOST*_\n\n_*Digite [ ${prefix}menu ] Para ver o menu do Bot*_`
				let buff = await getBuffer(ppimg)
				lorien.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} 
       if (anu.action == 'leave') {
				num = anu.participants[0]
				try {
					ppimg = await lorien.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `_*ESSE FDP*_ @${num.split('@')[0]} _*KITOU DO GRUPO*_ *${mdata.subject}*\n_*JA TAVA DEMORANDO A SAIRKKK*_`
				let buff = await getBuffer(ppimg)
				lorien.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
				lorien.sendMess(from, axios.get, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
			} 

		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	lorien.on('CB:Blocklist', json => {
      if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	lorien.on('chat-update', async (mek) => {
		try {
   if (!mek.hasNewMessage) return
      mek = JSON.parse(JSON.stringify(mek)).messages[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const apiKey = 'SLpvUgOcMYwIx0pFeELt'
      	const apikey = 'O8mUD3YrHIy9KM1fMRjamw8eg'
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
   var pes = (type === 'conversation' && mek.message.conversation) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text ? mek.message.extendedTextMessage.text : ''

			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
 		const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)

const sotoy = [
		 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
   '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
	 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : ',
	 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
	 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
  '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
	 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
	 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
	 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
  '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
	 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		'🐵 : 🐵 : 🐵',
		'🐊 : 🐊 : 🐊',
		'🐦 : 🐦 : 🐦'
		]
		const sotoy2 = [
		 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
   '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
   '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
   '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		 '🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		 '🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		'🐵 : 🐵 : 🐵',
		'🐊 : 🐊 : 🐊',
		'🐦 : 🐦 : 🐦'
		]
		const sotoy3 = [
		 '🐒 : 🐊 : 🐧',
		'🐊 : 🐵 :🐒',
		'🦍 : 🐊 : 🐧',
	 '🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
  '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		'🐒 : 🐊 : 🐊',
		'🦧 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		'🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		'🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		'🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
  '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 :🐧',
		'🐒 : 🐊 : 🐊',
		'🐵 : 🐵 :🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		'🐒 : 🦧 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐵 : 🐧 : 🦍',
		'🐒 : 🐊 : 🐧',
		'🐊 : 🐵 : 🐒',
		'🦍 : 🐊 : 🐧',
		'🐒 : 🦧 : 🐵',
		'🐵 : 🐊 : 🐧',
		'🐵 : 🐊 : 🐒',
  '🐒 : 🦧 : 🐵',		
		'🐧 : 🐊 : 🦧',
		'🐧 : 🐧 : 🐧',
		'🐒 : 🐊 : 🐊',
		'🐵 : 🐵 : 🦍',
		'🐦 : 🐊 : 🐵',
		'🐧 : 🐵 : 🐵',
		'🐒 : 🐵 : 🐊',
		'🦧 : 🦧 : 🐦',
		'🐵 : 🐵 : 🦍',
		'🐧 : 🐧 : 🦍',
		'🐵 : 🐵 : 🐵',
		'🐊 : 🐊 : 🐊',
		'🐦 : 🐦 : 🐦'
]

			mess = {
			 pro: '_*Apenas membros Premiums podem usar esse comando, para saber mais use : 「 ${prefix}vpremium 」*_',
			 erro: '_*Ocorreu algum erro, tente de movo*_',
			 load: '_*Carregando...*_',
			 demora: '_*Isso pode demorar um pouco, caso nao funcione tente de novo*_',
				wait: '_*Por favor, espere*_',
				success: '_*Deu certo*_',
				error: {
					stick: '_*ocorreu um erro ao converter a imagem em figurinha*_',
					Iv: '?? Link tidak valid ??'
				},
				only: {
					group: '_*Fale com o Zuoos para usar o bot*_\n\n_*Para falar com ele : wa.me/5563992674217*_',
					ownerG: '_*este comando so pode ser usado pelo Zuoos*_',
					ownerB: '_*O bot ainda nao e admin do grupo*_',
					admin: '_*Este comando so pode ser usado por admins*_',
					Badmin: '_*O bot ainda nao e admin do grupo*_',				
					daftarB: '_*Registre-se no banco de dados do bot para usalo*_\n\n_*Para registrar-se digite : 「 ${prefix}rg 」*_'
						}				
			}

			const botNumber = lorien.user.jid
			const ownerNumber = ["556392674217@s.whatsapp.net", "994406148962@s.whatsapp.net"] // replace this with your number
			const premium = ["556392674217@s.whatsapp.net","994406148962@s.whatsapp.net"] 

			const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await lorien.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : true
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isPremium = premium.includes(sender)
			const isRegister = checkRegisteredUser(sender)

			const tescuk = ["0@s.whatsapp.net"]
			let pushname = lorien.contacts[sender] != undefined ? lorien.contacts[sender].vname || lorien.contacts[sender].notify: undefined
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				lorien.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				lorien.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? lorien.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : lorien.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}

			colors = ['red','white','black','blue','yellow','green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			switch(command) {
			
			        // menus   
			 case 'bases':
				case 'base':
								  			if (!isGroup) return reply(mess.only.group)
								   	lorien.sendMessage(from, bases(prefix), text)        
    break           
				case 'imunes':
				case 'imune':
								  			if (!isGroup) return reply(mess.only.group)
								   	lorien.sendMessage(from, imunes(prefix), text)        
    break         
			 case 'comandos':       
				case 'help':
				case 'menu':
				   	lorien.sendMessage(from, help(prefix), text)        
				   	break
		 	case 'linguas':
				case 'idiomas':
				case 'idioma':
								  			if (!isGroup) return reply(mess.only.group)
  		lorien.sendMessage(from, idiomas(prefix), text)
	  	break
			 case 'apps':
				case 'aplicativos':
   
								  			if (!isGroup) return reply(mess.only.group)
								   	lorien.sendMessage(from, apps(prefix), text)        
			 break
			 case 'apps2':
				case 'aplicativos2':
   
								  			if (!isGroup) return reply(mess.only.group)
								   	lorien.sendMessage(from, apps2(prefix), text)        
			 break
										
					      //registrar e premiuns 
            			      
			        //entretenimento ou informacoes     	
case 'chance':
              lorien.updatePresence(from, Presence.composing) 
                var avb = body.slice(7)
                if (args.length < 1) return lorien.sendMessage(from, `_*Digite de forma correta*_\n_*Exemplo: ${prefix}chance do Zuoos comer seu canequin*_`, text, {quoted: mek})
                random = `${Math.floor(Math.random() * 100)}`
               hasil = `_*A chance${body.slice(7)}*_\n\n_*é de... ${random}%*_`
             lorien.sendMessage(from, hasil, text, {quoted: mek, contextInfo: {mentionedJid: [sender]}})
                break  			        
			 case 'bixo':
			 				  			if (!isGroup) return reply(mess.only.group)
 const somtoy = sotoy[Math.floor(Math.random() * (sotoy.length))]	
          const somtoy2 = sotoy2[Math.floor(Math.random() * (sotoy2.length))]	
          const somtoy3 = sotoy3[Math.floor(Math.random() * (sotoy3.length))]	
					lorien.sendMessage(from, slot(somtoy, somtoy2, somtoy3), text, {quoted: mek})
					break            
         case 'game':
         case 'jogo':
				  			if (!isGroup) return reply(mess.only.group)
         lorien.updatePresence(from, Presence.composing) 
        	const operadores =['+', '-', '÷', 'x']
        	const soma = operadores[Math.floor(Math.random() * operadores.length)] 
         responda = `${Math.floor(Math.random() * 100)}`
         responda2 = `${Math.floor(Math.random() * 100)}`        
         resultado = `_*Se tu e foda responde ai*_\n\n_*Quanto e : ${responda} `+soma+` ${responda2} ?*_`
         reply(resultado)
         break
					case 'destrava':
					if (!isGroup) return reply(mess.only.group)
					lorien.sendMessage(from, destrava(prefix), text)
					break
				case 'dono':
				 reply (mess.wait)
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.imgur.com/BpHGYQY.jpg`) 
					lorien.sendMessage(from, buffer, image, {quoted: mek, caption: '_*Lorien Bot*_\n\n_*Dono do bot : Zuoos*_\n_*Wpp: wa.me/5563992674217*_\n_*Canal: https://youtube.com/c/ZuoosEditsYt*_\n_*Instagram : @zuoos.amp*_\n_*Versao do Bot : V2.2*_\n_*Grupo Oficial :*_\n\n_*https://chat.whatsapp.com/BRxjrc6x8uUInr3rKSIfUl*_'})
					break
			 	case 'att':
				 case 'update':
	   	 		lorien.sendMessage(from, update(prefix), text)
		  	break
					  case 'hash':
					    if (!isGroup) return reply(mess.only.group)
	       	if (args.length < 1) return reply ('_*escolha entre X ou O e chame um amigo para jogar :)*_\n\n###\n###\n###')
	        	break          
					case 'feiura':
					if (!isGroup) return reply(mess.only.group)
        lorien.updatePresence(from, Presence.composing) 
         random = `${Math.floor(Math.random() * 100)}`
         hasil = `_*Seu nivel de feiurakkk :*_ \n\n_*Voce e  :*_ *${random}%* _*Feiokkk*_`
        reply(hasil)
    break
					case 'gado':
					if (!isGroup) return reply(mess.only.group)
        lorien.updatePresence(from, Presence.composing) 
         random = `${Math.floor(Math.random() * 100)}`
         hasil = `_*Seu nivel de gadisse :*_ \n\n_*voce e :*_ *${random}%* _*gadokkk*_`
        reply(hasil)
    break
      case 'beleza':
		 			if (!isGroup) return reply(mess.only.group)
         lorien.updatePresence(from, Presence.composing) 
         random = `${Math.floor(Math.random() * 100)}`
         hasil = `_*Seu nivel de beleza :*_ \n\n_*voce e :*_ *${random}%* _*lindo uiuiui*_`
        reply(hasil)
    break
    
         //funcoes  
case 'ytmp4':
				  			if (!isGroup) return reply(mess.only.group)
  reply(mess.wait)
  play = body.slice(7)
  try {
  anu = await fetchJson(`https://api.zeks.xyz/api/ytmp4?url=${play}&apikey=apivinz`)
  if(!isUrl(args[0]) && !args[0].includes('youtu')) return reply('Esse link não é do YouTube')
  if (anu.error) return reply(anu.error)
  infomp3 = `_*「INFORMAÇÕES DO VÍDEO 」*_\n_*➤ Título : ${anu.result.title}*_\n_*➤ Fonte : ${anu.result.source}*_\n_*➤ Tamanho : ${anu.result.size}*_\n_*➤ Link de donwload : ${anu.result.url_video}*_\n\n_*Aguarde, o video sera enviado*_`
  buffer = await getBuffer(anu.result.thumbnail)
  lagu = await getBuffer(anu.result.url_video)
  lorien.sendMessage(from, buffer, image, {
quoted: mek, caption: infomp3
  })
  lorien.sendMessage(from, lagu, video, {
mimetype: 'video/mp4', filename: `${anu.result.title}.mp4`, quoted: mek
  })
  
  } catch {
    reply(mess.ferr)
  }
  break           
case 'infogp':
case 'infogc':
case 'groupinfo':
case 'infogrup':
case 'grupinfo':               
                lorien.updatePresence(from, Presence.composing)
                if (!isGroup) return reply(mess.only.group)
                let { owner, creation, participants, desc } = groupMetadata;
                const creationTime = moment.unix(creation);
                try {
					ppUrl = await lorien.getProfilePicture(from)
					} catch {
					ppUrl = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
					}
                reply(mess.wait) 
			    buffer = await getBuffer(ppUrl)
		        lorien.sendMessage(from, buffer, image, {quoted: mek, caption: `_*「 INFORMACOES DO GRUPO 」*_\n\n_*➤ Nome : ${groupName}*_\n_*➤ Quantidade se membros : ${groupMembers.length}*_\n_*➤ Administradores : ${groupAdmins.length}*_\n_*➤ Descrição :*_ ${desc ? desc : ''}*_\n_*➤ Criador : wa.me/${owner.split('@')[0]}*_\n_*➤ Total de membros : ${participants.length}*_`})
                break     
case 'infome':
case 'perfil':
reply(mess.load)
if (!isGroup) return reply(mess.only.group)
    try {
ppimg = await lorien.getProfilePicture(`${sender.split('@')[0]}@c.us`)
  } catch {
ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
  }
 const pf = 
`_*「 INFORMAÇÕES DE PERFIL 」*_
                   *「 ⎙ 」*
━━━━━━━━᪥━━━━━━━━
  _*➤ Nome: ${pushname}*_

  _*➤ Número: @${sender.split("@")[0]}*_

  _*➤ Link: wa.me/${sender.split("@")[0]}*_
━━━━━━━━᪥━━━━━━━━ 

`
break                
case 'on':                      
case 'online':
				  			if (!isGroup) return reply(mess.only.group)
        		let ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : from
			    let online = [...Object.keys(lorien.chats.get(ido).presences), lorien.user.jid]
			    lorien.sendMessage(from, '_*Membros onlines agora :*_\n' + online.map(v => '➤ @' + v.replace(/@.+/, '')).join`\n`, text, { quoted: mek,
  			  contextInfo: { mentionedJid: online }
			    })
				break          
    case 'bug':
    case 'reportar':
    case 'reportarbug':
         const pesan = body.slice(5)
          if (pesan.length > 300) return lorien.sendMessage(from, '_*Textl muito grande, maximo 300 letras*_', msgType.text, {quoted: mek})
      var nomor = mek.participant
           const teks1 = `*「 Bug reportado para ser reparado 」*\n_*➤ Reportador :*_ @${nomor.split("@s.whatsapp.net")[0]}\n_*➤ Mensagem :*_ ${pesan}`
          var options = {
       text: teks1,
       contextInfo: {mentionedJid: [nomor]},
         }
        lorien.sendMessage('556392674217@s.whatsapp.net', options, text, {quoted: mek})
        reply('_*Bug reportado com sucesso*_\n\n_*Mensagens que nao estao relacionadas a bugs ou sugestoes nao serao respondidas*_\n\n\n_*Obrigado por esta reportando erros ou dando sugestoes :)*_')
        break					 
      case 'bloqueados':
			        	case 'blocklist':
				if (!isGroup) return reply(mess.only.group)
					teks = '_*Esta e a lista de numeros bloqueados :*_\n'
					for (let block of blocked) {
						teks += `_*➤ @${block.split('@')[0]}*_\n`
					}
					teks += `_*Total : ${blocked.length}*_`
					lorien.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break
				case 'ocr':
			 	if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						reply(mess.wait)
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply('esse comando e inutil n use')
					}
					break
				case 's':
				case 'figu':
				case 'stiker':
				case 'sticker':
 				if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`?? Falha ao converter ${tipe} para figurinha`)
							})
							.on('end', function () {
								console.log('Finish')
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'Your-ApiKey'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg.result, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Falha, esta faltando o codigo ai, bote o codigo e novamente')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								lorien.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
							})
						})
					/*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
					} else {
						reply(`_*Mande alguma midia com a legenda :*_\n\n_*[ ${prefix}sticker ]*_\n\n_*ou marque midias que ja foram enviadas*_`)
					}
					break
     case 'gtts':
		 		if (!isGroup) return reply(mess.only.group)
					if (args.length < 1) return lorien.sendMessage(from, '_*Escreva : [ ${prefix}idiomas ] para ver as linguas*_', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return lorien.sendMessage(from, '_*Ta faltando o texto*_', text, {quoted: mek})
					dtt = body.slice(9)
					ranm = getRandom('.mp3')
					dtt.length > 600
					? reply('_*muito grande vou le  naokkk*_')
					: gtts.save(ranm, dtt, function() {
						lorien.sendMessage(from, fs.readFileSync(ranm), audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
						fs.unlinkSync(ranm)
					})
					break
					case 'wame':
									  if (!isGroup) return reply(mess.only.group)
     lorien.updatePresence(from, Presence.composing) 
     options = {
     text: `_*LINK WHATSAPP*_\n\n_*Solicitado por: *@${sender.split("@s.whatsapp.net")[0]}*_\n\n_*Seu link do Whatsapp : wa.me/${sender.split("@s.whatsapp.net")[0]}*_\n\n_*Versao em barra : ( / )*_\n\n_*api.whatsapp.com/send?phone=${sender.split("@")[0]}*_`,
     contextInfo: { mentionedJid: [sender] }
    }
    lorien.sendMessage(from, options, text, { quoted: mek } )
				break					           
				case 'listadmins':
				case 'adminslist':
				case 'admins':				
					if (!isGroup) return reply(mess.only.group)
					teks = `_*Lista de admins do grupo : ${groupMetadata.subject}*_\n_*Total : ${groupAdmins.length}*_\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
    case 'linkgp':  
          reply (mess.wait)
          if (!isGroup) return reply(mess.only.group)
          if (!isBotGroupAdmins) return reply(mess.only.Badmin)
          linkgc = await lorien.groupInviteCode(from)
          reply('_*link do Grupo :*_ https://chat.whatsapp.com/'+linkgc)
          break
        case 'kitar':
          reply('_*Tchau, vou sair do grupo*_')
          if (!isGroup) return reply(mess.only.group)
          if (isGroupAdmins || is) {
              lorien.groupLeave(from)
          } else {
              reply(mess.only.admin)
          }
          break             
   		case 'toimg':
 				if (!isGroup) return reply(mess.only.group)
					if (!isQuotedSticker) return reply('_*responda uma figurinha*_')
					reply(mess.wait)
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await lorien.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply('_*Este comando so converte figurinhas que sao imagens*_')
						buffer = fs.readFileSync(ran)
						lorien.sendMessage(from, buffer, image, {quoted: mek, caption: '_*Ta aqui sua imagem*_'})
						fs.unlinkSync(ran)
					})
					break     
    case 'wait':
 				if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(mess.wait)
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await lorien.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							lorien.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply('_*mande uma foto  com o comando para ter resultados*_')
					}
     break
					case 'meme':
					reply (mess.wait)
					if (!isGroup) return reply(mess.only.group)
					data = fs.readFileSync('./src/meme.js');
     jsonData = JSON.parse(data);
     randIndex = Math.floor(Math.random() * jsonData.length);
     randKey = jsonData[randIndex];
     buffer = await getBuffer(randKey.result)
				lorien.sendMessage(from, buffer, image, {caption: '_*kapa kapa*_', quoted: mek})
       					break
    
        //comandos para adimins   
        
 case 'marcar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `_*➤ @${mem.jid.split('@')[0]}*_\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break
  case 'promover':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('_*Marque um membro para perder o ,admin*_')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Promovido com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(from, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*Esse fdp aqui : @${mentioned[0].split('@')[0]} agora e admin*_`, mentioned, true)
						lorien.groupMakeAdmin(from, mentioned)
					}
					break
				case 'rebaixar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('_*Marque um membro para ganhar admin*_')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Rebaixado com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*Esse fdp aqui : @${mentioned[0].split('@')[0]} Perdeu o admin*_`, mentioned, true)
						lorien.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'add':			 
 				if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply('_*quem voce deseja adicionar?*_')
					if (args[0].startsWith('08')) return reply('_*Use o codigo do pais amigo*_')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						lorien.groupAdd(from, [num])	
							} catch (e) {
						console.log('Error :', e)
						reply('Falha ao adicionar a pessoa, talvez seja porque esteja privado')
					}
					break
				case 'ban':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('_*Marque o fila da puta pra levar o ban hehehe*_')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedidos recebidos, emitidos :\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*O trouxa levou bankkk XD*_ : @${mentioned[0].split('@')[0]}`, mentioned, true)
						lorien.groupRemove(from, mentioned)
					}
					break
 case 'fechargp':
	
			lorien.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					var nomor = mek.participant
					const close = {
					text: `_*O GRUPO FOI FECHADO POR*_ @${nomor.split("@s.whatsapp.net")[0]}\n\n_*APENAS ADMS PODEM MANDAR MENSAGENS*_`,
					contextInfo: { mentionedJid: [nomor] }
					}
					lorien.groupSettingChange (from, GroupSettingChange.messageSend, true);
					reply(close)
					break
    case 'abrirgp':
					lorien.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					open = {
					text: `_*O GRUPO FOI ABERTO POR*_ @${sender.split("@")[0]}\n\n_*TODOS OS MEMBROS PODEM MANDAR MENSAGENS*_`,
					contextInfo: { mentionedJid: [sender] }
					}
					lorien.groupSettingChange (from, GroupSettingChange.messageSend, false)
					lorien.sendMessage(from, open, text, {quoted: mek})
					break       

									case 'bv':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('_*1 para ativar, 0 para desativar*_')
					if (Number(args[0]) === 1) {
					if (isWelkom) return reply('_*Ja ativo*_')
						welkom.push(from)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('_*Ativo o recurso de boas-vindas neste grupo*_')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('_*Desativou o recurso de boas-vindas neste grupo*_')
					} else {
						reply('_*1 para ativar, 0 para desativar*_')
					}
              break				        					
       					
       //comandos para owner
       
     case 'arquivar':
 				if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerG)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `_*Tchauzinho :*_ ${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					lorien.groupRemove(from, members_id)
					break         
				case 'gpess':
				if (!isOwner) return reply(`_*Comando inutilizavel*_`)				
				if (!isGroup) return reply(mess.only.group)
				lorien.sendMessage(from, gpessoa(prefix), text)
					break
				case 'gcp':
					if (!isOwner) return reply(`_*Comando inutilizavel*_`)				
 				if (!isGroup) return reply(mess.only.group)
					lorien.sendMessage(from, gcpf(prefix), text)
					break
						   case 'setprefix':    	
     	   case 'mudar prefixo':     	
	     			case 'mudarprefix':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.B)
					prefix = args[0]
					reply(`_*O PREFIXO FOI ALTERADO COM SUCESSO PARA :*_\n\n _*[ ${prefix} ]*_`)
					break
case 'clone':
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.ownerG)
					if (args.length < 1) return reply('_*A tag da pessoa que voce deseja clonar a foto*_')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('marque uma pessoa para clonar a foto de perfil')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await lorien.getProfilePicture(id)
						buffer = await getBuffer(pp)
						lorien.updateProfilePicture(botNumber, buffer)
						mentions(`_*Roubei a foto de perfil do :*_ @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply('falhou')
					}
					break
     case 'setfoto':
     reply(mess.wait)
					if (!isOwner) return reply(mess.only.ownerG())
			  lorien.updatePresence(from, Presence.composing) 
					if (!isQuotedImage) return reply(`_*mande uma imagen e depois marque com :*_ \n\n*[ ${prefix}setphoto ]*\n\n_*para mudar a foto de perfil do bot*_`)
					enmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await lorien.downloadAndSaveMediaMessage(enmedia)
					await lorien.updateProfilePicture(botNumber, media)
					reply('_*Foto de perfil atualizada com sucesso*_')
	     				break
					case 'setname':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.ownerG) 
					name = body.slice(12)
					reply(`_*O nome do bot foi alterado para : [ ${name} ]*_`)
					break
					case 'tm':
					lorien.updatePresence(from, Presence.composing) 
					if (!isOwner) return reply(mess.only.ownerG)
					if (args.length < 1) return reply('.......')
					anu = await lorien.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await lorien.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							lorien.sendMessage(_.jid, buff, image, {caption: `*[ TRANSMISSAO ]*\n\n${body.slice(4)}`})
						}
						reply('')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `*[ Transmissao de aviso ]*\n\n_*[ ${body.slice(4)} ]*_`)
						}
						reply('TRANSMISSAO FEITA')
					}
					break
       					
        //comandos de imagens e textos em fotos 
case 'neko':
				  			if (!isGroup) return reply(mess.only.group)
lorien.updatePresence(from, Presence.composing)
uk = ["anime neko"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
lorien.sendMessage(from, pok, image, {
  quoted: mek, caption: `_*Nyan*_`
})

} catch {
  reply(mess.ferr)
}
break

//--Pinteres anime loli
  case 'loli':
  				  			if (!isGroup) return reply(mess.only.group)
lorien.updatePresence(from, Presence.composing)
uk = ["anime loli"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
lorien.sendMessage(from, pok, image, {
  quoted: mek, caption: `_*kawaii*_`
})

} catch {
  reply(mess.ferr)
}
break

 case 'shit':
 				  			if (!isGroup) return reply(mess.only.group)
lorien.updatePresence(from, Presence.composing)
uk = ["shitpost br"]
nk = uk[Math.floor(Math.random() * uk.length)]
try {
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
lorien.sendMessage(from, pok, image, {
  quoted: mek, caption: `_*HuMoR e PiAdAs*_`
})

} catch {
  reply(mess.ferr)
}
break
  case 'anime':
  				  			if (!isGroup) return reply(mess.only.group)
lorien.updatePresence(from, Presence.composing)
am = ["anime tumblr",
  "wallpaper anime hd",
  "anime aestethic",
  "anime hd"]
nk = am[Math.floor(Math.random() * am.length)]
data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
  method: 'get'
})
reply(mess.wait)
n = JSON.parse(JSON.stringify(data));
nimek = n[Math.floor(Math.random() * n.length)];
pok = await getBuffer(nimek)
lorien.sendMessage(from, pok, image, {
  quoted: mek, caption: `_*Prontinho man*_`
})
break
  case 'wp':
  case 'wallpaper':
  				  			if (!isGroup) return reply(mess.only.group)
  lorien.updatePresence(from, Presence.composing)
  pw = ["wallpaper aestethic",
"wallpaper tumblr",
"wallpaper lucu",
"wallpaper"]
  nk = pw[Math.floor(Math.random() * pw.length)]
  try {
  data = await fetchJson(`https://api.fdci.se/sosmed/rep.php?gambar=${nk}`, {
method: 'get'
  })
  reply(mess.wait)
  n = JSON.parse(JSON.stringify(data));
  nimek = n[Math.floor(Math.random() * n.length)];
  pok = await getBuffer(nimek)
  lorien.sendMessage(from, pok, image, {
quoted: mek, caption: "_*Kilindo cara*_"
  })
  
  } catch {
    reply(mess.ferr)
  }
  break
case 'wall':
     reply(mess.wait)
     if (!isGroup) return reply(mess.only.group)
					data = fs.readFileSync('./src/wallpaper.json');
     jsonData = JSON.parse(data);
     randIndex = Math.floor(Math.random() * jsonData.length);
     randKey = jsonData[randIndex];
     buffer = await getBuffer(randKey.result)
				lorien.sendMessage(from, buffer, image, {caption: '_*Protinho man*_', quoted: mek})
     break
		
         //comandos de alteracoes

					case 'gnome':
     if (!isGroup) return reply(only.group)
			  if (!isGroupAdmins) return reply(mess.only.admin)
	 	  if (!isBotGroupAdmins) return reply(only.badmin)
     lorien.groupUpdateSubject(from, `${body.slice(7)}`)
     lorien.sendMessage(from, '_*NOME DO GRUPO ALTERADO COM SUCESSO*_', text, {quoted: mek})
     break
					case 'gfoto':
         					reply (mess.wait)
        if (!isGroup) return reply(mess.only.group)
        if (!isGroupAdmins) return reply(mess.only.admin)
        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
       	if (!isQuotedImage) return reply(`_*mande uma imagen e depois marque com :*_ \n\n*[ ${prefix}gfoto ]*\n\n_*para mudar a foto de perfil do grupo*_`)
					enmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await lorien.downloadAndSaveMediaMessage(enmedia)
					await lorien.updateProfilePicture(from, media)
	        reply('_*FOTO DO GRUPO ALTERADO COM SUCESSO*_')
        break
				
     //comandos de voz
       
          
       case 'troll':
       if (!isGroup) return reply(mess.only.group)
       const audio = fs.readFileSync('audio/troll.mp3')
lorien.sendMessage(from, audio, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break      
       case 'whatsapp2':
       if (!isGroup) return reply(mess.only.group)
       const audio2 = fs.readFileSync('audio/zipzop.mp3')
lorien.sendMessage(from, audio2, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break     
       case 'xxx':
       if (!isGroup) return reply(mess.only.group)
       const audio3 = fs.readFileSync('audio/xxx.mp3')
lorien.sendMessage(from, audio3, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break

       case 'meee':
       if (!isGroup) return reply(mess.only.group)
       const audio4 = fs.readFileSync('audio/meee.mp3')
lorien.sendMessage(from, audio4, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break   
       case 'pdp':
       if (!isGroup) return reply(mess.only.group)
       const audio5 = fs.readFileSync('audio/pdp.mp3')
lorien.sendMessage(from, audio5, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break      
       case 'porrr':
       if (!isGroup) return reply(mess.only.group)
       const audio6 = fs.readFileSync('audio/fuderkkk.mp3')
lorien.sendMessage(from, audio6, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break 
       case 'rapaa':
       if (!isGroup) return reply(mess.only.group)
       const audio7 = fs.readFileSync('audio/rapaa.mp3')
lorien.sendMessage(from, audio7, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break     
       case 'noia':
       if (!isPremium) return reply(mess.pro)
       if (!isGroup) return reply(mess.only.group)
       const audio8 = fs.readFileSync('audio/noia.mp3')
lorien.sendMessage(from, audio8, MessageType.audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})    
       break        
                           
     //consultas
    
     
case 'cep':
if (!isOwner) return reply(mess.only.ownerG)
if (args.length < 1) return reply('_*Escreva um cep para realizar a busca*_')
cep = body.slice(4)
hehe = await fetchJson(`https://brasilapi.com.br/api/cep/v1/${cep}`)
ccg =
`_*「 INFORMAÇÕES DO CEP 」*_
                *「 ⎙ 」*
━━━━━━━᪥━━━━━━━
  _*➤ Cep : ${hehe.cep}*_
  _*➤ Estado : ${hehe.state}*_
  _*➤ Cidade : ${hehe.city}*_
━━━━━━━᪥━━━━━━━ 
  `
lorien.sendMessage(from, ccg, text, {quoted:mek})
break
 

                 	
     //testes
        
													      	        			  			      	        			  			      	        			  			      	        			  			      	        			  			      	        			  			      	        			  			      	        			  			      	        			  			      	        			  												
                  case 'nsfw':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('Digite =nsfw 1 para ativar')
					if (Number(args[0]) === 1) {
					if (isNsfw) return reply('O NSFW já está ativo no grupo')
						nsfw.push(from)
						fs.writeFileSync('./lib/nsfw.json', JSON.stringify(nsfw))
						reply('_*Ja ativo*_')
					} else if (Number(args[0]) === 0) {
						nsfw.splice(from, 1)
						fs.writeFileSync('./lib/nsfw.json', JSON.stringify(nsfw))
						reply('_*Nsfw desativado no grupo*_')
					} else {
						reply('_*1 para ativar, 0 para desativar*_')
					}
					break							
  its = await getBuffer (ppimg)
  lorien.sendMessage(from, its, image, {quoted: mek, caption: pf, contextInfo: {mentionedJid: [sender]}})
  break
  
     //acabou os comandos        
  default:
				if (body.startsWith(`${prefix}${command}`)) {
                hsl = `_*Olar @${sender.split("@")[0]} tenho que te avisar algo*_\n_*O comando que vc digitou esta errado ou não existe, escreva 「${prefix}menu」 para ver os comandos*_`
  lorien.sendMessage(from, hsl, text, {quoted: mek, contextInfo: {mentionedJid: [sender]}})
				}
      if (isGroup && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						console.log(muehe)
						reply(muehe)
					} else {
						console.log(color('invalido','red'), 'comando nao registrado de :', color(sender.split('@')[0]))
					}
                           }
		} catch (e) {
			console.log('Error : %s', color(e, 'green'))
		}
	})
}
starts()

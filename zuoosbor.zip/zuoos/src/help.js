const help = (prefix) => {
	return `*════𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩∆Bot∆════*


➸ Prefix:  *「${prefix} 」*
➸ Status: *「 Online ✓」*

     ╔════𖠇════╗
       *༺[Stickers 🐒]༻*
     ╚════𖠇════╝
      
➸ Comando : *${prefix}sticker* ou *${prefix}stiker*
➸ útil em : converter imagem/gif/vídeo em adesivo
➸ uso : responder imagem/gif/video ou enviar imagem/gif/video com legenda

➸ Comando : *${prefix}sticker nobg* ou *${prefix}stiker nobg*
➸ útil em : converter imagem em adesivo removendo o fundo
➸ uso : responder imagem ou enviar imagem com legenda

➸ Comando : *${prefix}toimg*
➸ útil em : converter adesivo em imagem
➸ uso : adesivo de resposta

    ╔════════𖠇════════╗
        *༺[OUTRAS PARADA AE...🙈]༻* 
    ╚════════𖠇════════╝
       
➸ Comando : *${prefix}meme*
➸ útil em : mandar imagens aleatórias de meme [inglês]
➸ uso : basta enviar o comando

➸ Comando : *${prefix}gtts*
➸ útil em : converter texto em fala/áudio
➸ uso : *${prefix}gtts [cc] [text]*\nexemplo : *${prefix}gtts ja On2-chan*

➸ Comando : *${prefix}loli*
➸ útil em : mandar imagens aleatórias de loli
➸ uso : basta enviar o comando

➸ Comando : *${prefix}nsfwloli*
➸ útil em : mandar imagens aleatórias de nsfw loli
➸ uso : basta enviar o comando

➸ Comando : *${prefix}ocr*
➸ útil em : pegar o texto da foto e lhe enviar
➸ uso : responder imagem ou enviar mensagem com legenda

➸ Comando : *${prefix}wait*
➸ útil em : pesquisar sobre o anime por imagem [ Que anime é este/que ]
➸ uso : responder imagem ou enviar imagem com legenda

    ╔════𖠇════╗
       *༺[GROUP🙈]༻*
    ╚════𖠇════╝
    
➸ Comando : *${prefix}listadmins*
➸ útil em : mostrar admins do grupo
➸ uso : basta enviar o comando
   
➸ Comando : *${prefix}linkgroup*
➸ útil em : enviar o link do grupo
➸ uso : basta enviar o comando

➸ Comando : *${prefix}tagall*
➸ útil em : marcar todos os membros do grupo, incluindo administradores
➸ uso : basta enviar o comando
➸ Nota : Você precisa ser administrador do grupo

➸ Comando : *${prefix}add*
➸ útil em : adicionar membro ao grupo
➸ uso : *${prefix}add 5585xxxxx*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}kick*
➸ útil em : remover membros do grupo
➸ uso : *${prefix}kick e o @da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}promote*
➸ útil em : tornar membro do grupo um administrador
➸ uso : *${prefix}promote e o @da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}demote*
➸ útil em : tornar o administrador um membro comum
➸ uso : *${prefix}demote e o @da pessoa*
➸ Nota : Você precisa ser admin e o bot também

➸ Comando : *${prefix}welcome*
➸ útil em : ativa uma mensagem de boas vindas ao grupo
➸ uso : *${prefix}welcome 1 para ativar, 0 pra desativar 
➸ Nota : Usado somente em grupos 

    ╔═══════𖠇══════╗
      *༺[Comandos para Dono]༻*
    ╚═══════𖠇══════╝  

➸ Comando : *${prefix}setprefix*
➸ útil em : alterar o prefixo do bot
➸ uso : *${prefix}setprefix [texto|opcional]*\nexemplo : *${prefix}setprefix ?*
➸ Nota : Usado somente pelo proprietário do bot

➸ Comando : *${prefix}limpar*
➸ útil em : limpa os chats do bot
➸ uso : basta enviar o comando   
➸ Nota : Usado somente pelo dono
      
➸ Comando : *${prefix}blocklist*
➸ útil em : mostrar contatos bloqueados pelo Bot
➸ uso : basta enviar o comando
  
➸ Comando : *${prefix}ts*
➸ útil em : manda uma mensagem em transmissão
➸ uso : *${prefix}ts [text]*\nexemplo : *${prefix}ts Zuoos Brabo*\n
➸ Nota : Usado somente pelo dono
     
       ════════∆══════════
        *MENU 1 ༺𖤍ϟƵɄØØ$ϟ𖤍 🐊/̷🚩༻*
       ════════∆══════════   

➸ *${prefix}help1* 🐒
    

╔══════════════════════
     𖤍ϟƵɄØØ$ϟ𖤍* 🐊/̷🚩
     Dono: 👇
    wa.me/5563992674217
╚══════════════════════
Fale comigo antes de usar o bot!✨`
}

exports.help = help








const bases = () => { 
	return `_*[⇨         ᯽ BASES PARA MODDERS ᯽         ⇦]*_


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*⟐ Base 2.20.206.11 ⟐*_ 
https://suaurl.com/40b2df

_*⟐ Base 2.20.206.6 ⟐*_ 
https://suaurl.com/f32a33

_*⟐ YoWhatsApp V6.0 (anti-ban) ⟐*_ 
https://suaurl.com/354911

_*⟐ YoWhatsApp Gold V10.15 (anti-ban) ⟐*_
 https://suaurl.com/97a747
 
 _*⟐ YoWhatsApp V8.65 (anti-ban) ⟐*_ 
 https://suaurl.com/0f139e
 
 _*⟐ GBWhatsApp V11.00 (anti-ban) ⟐*_ 
https://suaurl.com/80b5a9

_*⟐ WhatsApp GO V0.20.113L (anti-ban) ⟐*_ 
https://suaurl.com/8935a5

_*⟐ FMWhatsApp V8.65 (anti-ban) ⟐*_ 
https://suaurl.com/c719b6

_*⟐ WhatsApp base quinaria  ⟐*_                  
 https://suaurl.com/35d7d5 
 ᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽        


_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.bases = bases
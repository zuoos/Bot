const update = (prefix) => {
	return `_*[⇨         ᯽Lorien Bot WhatsApp ᯽         ⇦]*_
	
	
᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Bot feito por : ⸸Zuoos⸸*_
_*➤ Numero do criador : wa.me/556392674217*_
_*➤ Versão do Bot : V2.1*_
_*➤ Para saber sobre a att escreva : [ ${prefix}update ]*_
_*➤ Meu canal : https://youtube.com/c/ZuoosEditsYt*_
_*➤ Instagram : @zuoos.amp*_
_*➤ Bot para grupos, não use no privado*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
┃━━━━━━━━━━━━━━━━━━┃
    _*⏣ Notas de atualização : 𝐋𝐨𝐫𝐢𝐞𝐧 𝐛𝐨𝐭 ⏣*_
┃━━━━━━━━━━━━━━━━━━┃
_*➤ Comandos foram adicionados :*_

_*⟐ Imunes ⟐*_ 
_*⟐ Bases ⟐*_ 

_*➤ Aplicativos foram adicionados em [ ${prefix}apps ]*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽


᯽━━━━━━━━━⟐†⟐━━━━━━━━━᯽
_*➤ Versão atual : V2.1*_
᯽━━━━━━━━━⟐⸸⟐━━━━━━━━━᯽
`
}

exports.update = update








const apps = () => { 
	return `
	_*Mods de aplicativos e jogos*_
	
_*Veja o menu de apps e mods :*_


                  _*APPS E JOGOS*_


• PowerDirector V9.0.0 (PRO) 
https://apkadmin.com/z8ldqam14d9b/PowerDirector-Premium-v9.0.0_build_96126-Mod_www.droidl.com.apk.html

• Teraria mobile V1.4.0.5.2.1 (Original)
https://www.mediafire.com/file/1uobj50akt5da1u/Terraria_v1.4.0.5.2.1_ByHT.apk/file

• AutoResponder (PRO)
https://www.mediafire.com/file/p8p6rtem1lh0bl1/DIFFAPK.COM_AutoResponder_for_WA_v1_9_5_Mod_By_ZackModz.apk/file

• Minecraft (Original)
https://www.mediafire.com/file/4hixmktsfkhky91/Minecraft_v1.16.101.01_Terbaru.zip/file

• KineMaster (PRO)
https://www.mediafire.com/download/eshb8rra8eg5xa3

• KineMaster Diamond (MOD)
https://www.mediafire.com/download/9p8wsnwupnq0lun

• KineMaster Ruby (MOD)
https://www.mediafire.com/download/6b2wa08cmtsr8x8

• Adobe Photoshop (Original)
https://www.mediafire.com/download/whfh12tj4zjpedp

• Alight Motion V3.6.1 (PRO) 
https://www.mediafire.com/file/0fpd60oiqt334hu/Alight_Motion_v3.6.1_Mod.apk/file

• Alight Motion V3.1.4 (PRO) 
http://www.mediafire.com/file/tpxj2grwf8imp6i/Alight_Motion_V.3.1.4_%2528Mod%2529_By_bilqis_neha.apk/file

• Avee Player (PRO)
https://www.mediafire.com/download/5vkde8d1gcyk33y

• Pixellab (PRO)
https://www.mediafire.com/download/kxj0xyvrkc8w6h0

• Inshot (PRO)
https://www.mediafire.com/download/7qcmrfdy2o1ynxf

• WavePad (PRO)
https://www.mediafire.com/download/oif50qb8ltdoe2x

• Vimage (PRO)
https://www.mediafire.com/download/egjumopr2wl89tl

• Zeotropic (PRO)
https://www.mediafire.com/download/tw9zwj2km2tjsnh

• 90s (PRO)
https://www.mediafire.com/download/0y2bba69f6wakuh


_*ZUOOS DOMINA PORR* 🤙🏻😎*_
`
}
exports.apps = apps
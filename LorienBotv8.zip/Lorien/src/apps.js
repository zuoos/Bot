const apps = () => { 
	return `
	_*Mods de aplicativos e jogos*_
	
_*Veja o menu de apps e mods :*_


                  _*APPS E JOGOS*_
                  
• GTA San (Original) 
https://www.mediafire.com/file/ln6r3kx0ie77r9t/GTA_San_Andreas_2021.zip/file

•bully (Original) 
http://www.mediafire.com/file/n2w1b3fc13jqvbv/Bully%2528apk%252Bobb%2529.zip/file

• InstaProMod(PRO) 
https://www.mediafire.com/file/89mdfbi893jvx49/InstaPro_v7.61_By_SamMods.apk/file

• PicsArtPro (PRO) 
http://www.mediafire.com/file/1zvldsslezyn637/PicsArt_Premium_Gratis.apk/file 

• PixellabMod (PRO) 
http://www.mediafire.com/file/pfe8lhc72n11z72/Pixellab+New+Mods+Aditya+Project.zip/file                 
                 
• spotify Premium (PRO) 
https://www.mediafire.com/file/r46qm088ni0zer6/Spotify_v8.5.89.901_AndroidFinal.com_.apk/file

• PowerDirector V9.0.0 (PRO) 
https://apkadmin.com/z8ldqam14d9b/PowerDirector-Premium-v9.0.0_build_96126-Mod_www.droidl.com.apk.html

• Teraria mobile V1.4.0.5.2.1 (Original)
https://www.mediafire.com/file/1uobj50akt5da1u/Terraria_v1.4.0.5.2.1_ByHT.apk/file

• AutoResponder (PRO)
https://www.mediafire.com/file/p8p6rtem1lh0bl1/DIFFAPK.COM_AutoResponder_for_WA_v1_9_5_Mod_By_ZackModz.apk/file

• Minecraft (Original)
https://www.mediafire.com/file/4hixmktsfkhky91/Minecraft_v1.16.101.01_Terbaru.zip/file

• KineMaster (PRO)
https://www.mediafire.com/download/eshb8rra8eg5xa3

• KineMaster Diamond (MOD)
https://www.mediafire.com/download/9p8wsnwupnq0lun

• KineMaster Ruby (MOD)
https://www.mediafire.com/download/6b2wa08cmtsr8x8

• Adobe Photoshop (Original)
https://www.mediafire.com/download/whfh12tj4zjpedp

• Alight Motion V3.6.1 (PRO) 
https://www.mediafire.com/file/0fpd60oiqt334hu/Alight_Motion_v3.6.1_Mod.apk/file

• Alight Motion V3.1.4 (PRO) 
http://www.mediafire.com/file/tpxj2grwf8imp6i/Alight_Motion_V.3.1.4_%2528Mod%2529_By_bilqis_neha.apk/file

• Avee Player (PRO)
https://www.mediafire.com/download/5vkde8d1gcyk33y

• Pixellab (PRO)
https://www.mediafire.com/download/kxj0xyvrkc8w6h0

• Inshot (PRO)
https://www.mediafire.com/download/7qcmrfdy2o1ynxf

• WavePad (PRO)
https://www.mediafire.com/download/oif50qb8ltdoe2x

• Vimage (PRO)
https://www.mediafire.com/download/egjumopr2wl89tl

• Zeotropic (PRO)
https://www.mediafire.com/download/tw9zwj2km2tjsnh

• 90s (PRO)
https://www.mediafire.com/download/0y2bba69f6wakuh


_*ZUOOS DOMINA KOROI ✓*_
`
}
exports.apps = apps
const {
    WAConnection,
    MessageType,
    Presence,
    Mimetype,
    GroupSettingChange
} = require('@adiwajshing/baileys')
const { color, bgcolor } = require('./lib/color')
const { help } = require('./src/help')
const { apps } = require('./src/apps')
const { gcpf } = require('./src/gcpf')
const { gpessoa } = require('./src/gpessoa')
const { destrava } = require('./src/destrava')
const { wait, simih, getBuffer, h2k, generateMessageID, getGroupAdmins, getRandom, banner, start, info, success, close } = require('./lib/functions')
const { fetchJson } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const fs = require('fs')
const moment = require('moment-timezone')
const { exec } = require('child_process')
const kagApi = require('@kagchi/kag-api')
const fetch = require('node-fetch')
const ffmpeg = require('fluent-ffmpeg')
const { removeBackgroundFromImageFile } = require('remove.bg')
const imgbb = require('imgbb-uploader')
const lolis = require('lolis.life')
const loli = new lolis()
const welkom = JSON.parse(fs.readFileSync('./src/welkom.json'))
const nsfw = JSON.parse(fs.readFileSync('./src/nsfw.json'))
const samih = JSON.parse(fs.readFileSync('./src/simi.json'))
prefix = '.'
blocked = []

function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);

  //return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
  return `${pad(hours)} Hora ${pad(minutes)} Minuto ${pad(seconds)} Segundo`
}

async function starts() {
	const lorien = new WAConnection()
	lorien.logger.level = 'warn'
	console.log(banner.string)
	lorien.on('qr', () => {
		console.log(color('[','white'), color('!','red'), color(']','white'), color('Escaneia o codigo blz'))
	})

	fs.existsSync('./BarBar.json') && lorien.loadAuthInfo('./BarBar.json')
	lorien.on('connecting', () => {
		start('2', 'Connecting...')
	})
	lorien.on('open', () => {
		success('2', 'Connected')
	})
	await lorien.connect({timeoutMs: 30*1000})
        fs.writeFileSync('./BarBar.json', JSON.stringify(lorien.base64EncodedAuthInfo(), null, '\t'))

	lorien.on('group-participants-update', async (anu) => {
		if (!welkom.includes(anu.jid)) return
		try {
			const mdata = await lorien.groupMetadata(anu.jid)
			console.log(anu)
			if (anu.action == 'add') {
				num = anu.participants[0]
				try {
					ppimg = await lorien.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `*OL?!!!* @${num.split('@')[0]}\n*BEM VINDO AO GRUPO:* *${mdata.subject}* \n*N?O SEJA GHOST*\n\n_*Digite [ ${prefix}menu ] Para ver o menu do Bot*_`
				let buff = await getBuffer(ppimg)
				lorien.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} 
       if (anu.action == 'remove') {
				num = anu.participants[0]
				try {
					ppimg = await lorien.getProfilePicture(`${anu.participants[0].split('@')[0]}@c.us`)
				} catch {
					ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
				}
				teks = `*ESSE FDP* @${num.split('@')[0]} *KITOU DO GRUPOKKK* *${mdata.subject}*\n*JA TAVA DEMORANDO A SAIR?��*`
				let buff = await getBuffer(ppimg)
				lorien.sendMessage(mdata.id, buff, MessageType.image, {caption: teks, contextInfo: {"mentionedJid": [num]}})
			} 

		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})

	lorien.on('CB:Blocklist', json => {
            if (blocked.length > 2) return
	    for (let i of json[1].blocklist) {
	    	blocked.push(i.replace('c.us','s.whatsapp.net'))
	    }
	})

	lorien.on('chat-update', async (mek) => {
		try {
                        if (!mek.hasNewMessage) return
                        mek = JSON.parse(JSON.stringify(mek)).messages[0]
			if (!mek.message) return
			if (mek.key && mek.key.remoteJid == 'status@broadcast') return
			if (mek.key.fromMe) return
			global.prefix
			global.blocked
			const content = JSON.stringify(mek.message)
			const from = mek.key.remoteJid
			const type = Object.keys(mek.message)[0]
			const apiKey = 'SLpvUgOcMYwIx0pFeELt'
            	const apikey = 'O8mUD3YrHIy9KM1fMRjamw8eg'
			const { text, extendedText, contact, location, liveLocation, image, video, sticker, document, audio, product } = MessageType
			const time = moment.tz('Asia/Jakarta').format('DD/MM HH:mm:ss')
			body = (type === 'conversation' && mek.message.conversation.startsWith(prefix)) ? mek.message.conversation : (type == 'imageMessage') && mek.message.imageMessage.caption.startsWith(prefix) ? mek.message.imageMessage.caption : (type == 'videoMessage') && mek.message.videoMessage.caption.startsWith(prefix) ? mek.message.videoMessage.caption : (type == 'extendedTextMessage') && mek.message.extendedTextMessage.text.startsWith(prefix) ? mek.message.extendedTextMessage.text : ''
			budy = (type === 'conversation') ? mek.message.conversation : (type === 'extendedTextMessage') ? mek.message.extendedTextMessage.text : ''
			const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
			const args = body.trim().split(/ +/).slice(1)
			const isCmd = body.startsWith(prefix)

			mess = {
				wait: '_*Por favor, espere*_',
				success: '_*Deu certo*_',
				error: {
					stick: '_*ocorreu um erro ao converter a imagem em figurinha*_',
					Iv: '?? Link tidak valid ??'
				},
				only: {
					group: '_*Fale com o Zuoos para usar o bot*_\n\n_*Para falar com ele : wa.me/5563992674217*_',
					ownerG: '_*este comando so pode ser usado pelo Zuoos*_',
					ownerB: '_*O bot ainda nao e admin do grupo*_',
					admin: '_*Este comando so pode ser usado por admins XD*_',
					Badmin: '_*O bot ainda nao e admin do grupo*_'
				}
			}

			const botNumber = lorien.user.jid
			const ownerNumber = ["556392674217@s.whatsapp.net"] 
						const isGroup = from.endsWith('@g.us')
			const sender = isGroup ? mek.participant : mek.key.remoteJid
			const groupMetadata = isGroup ? await lorien.groupMetadata(from) : ''
			const groupName = isGroup ? groupMetadata.subject : ''
			const groupId = isGroup ? groupMetadata.jid : ''
			const groupMembers = isGroup ? groupMetadata.participants : ''
			const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ''
			const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
			const isGroupAdmins = groupAdmins.includes(sender) || false
			const isWelkom = isGroup ? welkom.includes(from) : false
			const isNsfw = isGroup ? nsfw.includes(from) : true
			const isSimi = isGroup ? samih.includes(from) : false
			const isOwner = ownerNumber.includes(sender)
			const isUrl = (url) => {
			    return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
			}
			const reply = (teks) => {
				lorien.sendMessage(from, teks, text, {quoted:mek})
			}
			const sendMess = (hehe, teks) => {
				lorien.sendMessage(hehe, teks, text)
			}
			const mentions = (teks, memberr, id) => {
				(id == null || id == undefined || id == false) ? lorien.sendMessage(from, teks.trim(), extendedText, {contextInfo: {"mentionedJid": memberr}}) : lorien.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": memberr}})
			}

			colors = ['red','white','black','blue','yellow','green']
			const isMedia = (type === 'imageMessage' || type === 'videoMessage')
			const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
			const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
			const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
			if (!isGroup && isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (!isGroup && !isCmd) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'args :', color(args.length))
			if (isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;32mEXEC\x1b[1;37m]', time, color(command), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			if (!isCmd && isGroup) console.log('\x1b[1;31m~\x1b[1;37m>', '[\x1b[1;31mRECV\x1b[1;37m]', time, color('Message'), 'from', color(sender.split('@')[0]), 'in', color(groupName), 'args :', color(args.length))
			switch(command) {
				case 'help':
				case 'menu':
   					lorien.sendMessage(from, help(prefix), text)
					break
			 case 'apps':
				case 'aplicativos':
				if (!isGroup) return reply(mess.only.group)
				lorien.sendMessage(from, apps(prefix), text)
					break
				case 'gerar pessoa':
				case 'gerarpessoa':
				if (!isOwner) return reply(mess.only.ownerG)
				if (!isGroup) return reply(mess.only.group)
				lorien.sendMessage(from, gpessoa(prefix), text)
					break
				case 'gerar cpf':
				case 'gerarcpf':
				if (!isOwner) return reply(mess.only.ownerG)
				if (!isGroup) return reply(mess.only.group)
					lorien.sendMessage(from, gcpf(prefix), text)
					break
					case 'destrava':
					if (!isGroup) return reply(mess.only.group)
					lorien.sendMessage(from, destrava(prefix), text)
					break
				case 'blocklist':
				if (!isGroup) return reply(mess.only.group)
					teks = 'Esta �� a lista de n��meros bloqueados :\n'
					for (let block of blocked) {
						teks += `~> @${block.split('@')[0]}\n`
					}
					teks += `Total : ${blocked.length}`
					lorien.sendMessage(from, teks.trim(), extendedText, {quoted: mek, contextInfo: {"mentionedJid": blocked}})
					break
				case 'ocr':
			 	if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						reply(mess.wait)
						await recognize(media, {lang: 'eng+ind', oem: 1, psm: 3})
							.then(teks => {
								reply(teks.trim())
								fs.unlinkSync(media)
							})
							.catch(err => {
								reply(err.message)
								fs.unlinkSync(media)
							})
					} else {
						reply('esse comando e inutil n use')
					}
					break
				case 'figu':
				case 'stiker':
				case 'sticker':
				if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.input(media)
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								reply(mess.error.stick)
							})
							.on('end', function () {
								console.log('Finish')
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia && mek.message.videoMessage.seconds < 11 || isQuotedVideo && mek.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 11) && args.length == 0) {
						const encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						reply(mess.wait)
						await ffmpeg(`./${media}`)
							.inputFormat(media.split('.')[1])
							.on('start', function (cmd) {
								console.log(`Started : ${cmd}`)
							})
							.on('error', function (err) {
								console.log(`Error : ${err}`)
								fs.unlinkSync(media)
								tipe = media.endsWith('.mp4') ? 'video' : 'gif'
								reply(`?? Falha ao converter ${tipe} para figurinha`)
							})
							.on('end', function () {
								console.log('Finish')
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(media)
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)
					} else if ((isMedia || isQuotedImage) && args[0] == 'nobg') {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ranw = getRandom('.webp')
						ranp = getRandom('.png')
						reply(mess.wait)
						keyrmbg = 'Your-ApiKey'
						await removeBackgroundFromImageFile({path: media, apiKey: keyrmbg.result, size: 'auto', type: 'auto', ranp}).then(res => {
							fs.unlinkSync(media)
							let buffer = Buffer.from(res.base64img, 'base64')
							fs.writeFileSync(ranp, buffer, (err) => {
								if (err) return reply('Falha, esta faltando o codigo ai, bote o codigo e novamente')
							})
							exec(`ffmpeg -i ${ranp} -vcodec libwebp -filter:v fps=fps=20 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 512:512 ${ranw}`, (err) => {
								fs.unlinkSync(ranp)
								if (err) return reply(mess.error.stick)
								lorien.sendMessage(from, fs.readFileSync(ranw), sticker, {quoted: mek})
							})
						})
					/*} else if ((isMedia || isQuotedImage) && colors.includes(args[0])) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						const media = await lorien.downloadAndSaveMediaMessage(encmedia)
						ran = getRandom('.webp')
						await ffmpeg(`./${media}`)
							.on('start', function (cmd) {
								console.log('Started :', cmd)
							})
							.on('error', function (err) {
								fs.unlinkSync(media)
								console.log('Error :', err)
							})
							.on('end', function () {
								console.log('Finish')
								fs.unlinkSync(media)
								lorien.sendMessage(from, fs.readFileSync(ran), sticker, {quoted: mek})
								fs.unlinkSync(ran)
							})
							.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=${args[0]}@0.0, split [a][b]; [a] palettegen=reserve_transparent=off; [b][p] paletteuse`])
							.toFormat('webp')
							.save(ran)*/
					} else {
						reply(`Envie fotos com legendas ${prefix}sticker ou tags de imagem que já foram enviadas`)
					}
					break
				case 'gtts':
				if (!isGroup) return reply(mess.only.group)
					if (args.length < 1) return lorien.sendMessage(from, '_*cade o codigo do idioma?*_', text, {quoted: mek})
					const gtts = require('./lib/gtts')(args[0])
					if (args.length < 2) return lorien.sendMessage(from, '_*Ta faltando o texto*_', text, {quoted: mek})
					dtt = body.slice(9)
					ranm = getRandom('.mp3')
					dtt.length > 600
					? reply('_*muito grande vou le naokkk*_')
					: gtts.save(ranm, dtt, function() {
						lorien.sendMessage(from, fs.readFileSync(ranm), audio, {quoted: mek, mimetype: 'audio/mp4', ptt:true})
						fs.unlinkSync(ranm)
					})
					break
									  case 'wame':
									  if (!isGroup) return reply(mess.only.group)
  lorien.updatePresence(from, Presence.composing) 
      options = {
          text: `_*LINK WHATSAPP*_\n\n_*Solicitado por*_ : *@${sender.split("@s.whatsapp.net")[0]}\n\n_*Seu link do Whatsapp :*_ *wa.me/${sender.split("@s.whatsapp.net")[0]}*\n\n_*Versão em barra : ( / )*_\n\n*api.whatsapp.com/send?phone=${sender.split("@")[0]}*`,
          contextInfo: { mentionedJid: [sender] }
    }
    lorien.sendMessage(from, options, text, { quoted: mek } )			
			 	break	
				case 'dono':
					memein = await kagApi.memeindo()
					buffer = await getBuffer(`https://i.imgur.com/AMxwaUX.png`) 
					lorien.sendMessage(from, buffer, image, {quoted: mek, caption: '_*Dono do bot : Zuoos*_\n*Wpp:* wa.me/5563992674217\n*Canal:* https://youtube.com/c/ZuoosEditsYt\n *se inscreve no canal la man quero 1k *'})
					break
					          case 'hash':
					          if (!isGroup) return reply(mess.only.group)
	            	if (args.length < 1) return reply ('_*escolha entre X ou O e chame um amigo para jogar :)*_\n\n# # #\n# # #\n# # #')
	              	break
	              case 'updateinfor':
	            	if (args.length < 1) return reply ('_*NOTAS DE ATUALIZA??O DO BOT :*_\n\n_*NOTAS : Comandos foram adicionados ou tiveram reparos : feiura,  destrava...*_\n\n_*Versao Atual do Bot: V1.8*_\n\n_*Atualizacoes em breve!!!*_')
	              	break
	   case 'setprefix':          	
	   case 'mudar prefixo':           	
				case 'mudarprefixo':
					if (args.length < 1) return
					if (!isOwner) return reply(mess.only.B)
					prefix = args[0]
					reply(`_*O PREFIXO FOI ALTERADO COM SUCESSO PARA: [ ${prefix} ]*_`)
					break
				case 'marcar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					members_id = []
					teks = (args.length > 1) ? body.slice(8).trim() : ''
					teks += '\n\n'
					for (let mem of groupMembers) {
						teks += `*>>* @${mem.jid.split('@')[0]}\n`
						members_id.push(mem.jid)
					}
					mentions(teks, members_id, true)
					break
        case 'promover':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Promovido com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(from, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*Esse fdp aqui : @${mentioned[0].split('@')[0]} agora e admin*_`, mentioned, true)
						lorien.groupMakeAdmin(from, mentioned)
					}
					break
				case 'rebaixar':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Rebaixado com sucesso\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*Esse fdp aqui : @${mentioned[0].split('@')[0]} Nao e mais admin*_`, mentioned, true)
						lorien.groupDemoteAdmin(from, mentioned)
					}
					break
				case 'add':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (args.length < 1) return reply('quem voce deseja adicionar?')
					if (args[0].startsWith('08')) return reply('Use o codigo do pais amigo')
					try {
						num = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
						lorien.groupAdd(from, [num])
					} catch (e) {
						console.log('Error :', e)
						reply('Falha ao adicionar a pessoa, talvez seja porque esteja privado')
					}
					break
				case 'ban':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('_*Marque o fila da puta pra levar o ban hehehe*_')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid
					if (mentioned.length > 1) {
						teks = 'Pedidos recebidos, emitidos :\n'
						for (let _ of mentioned) {
							teks += `@${_.split('@')[0]}\n`
						}
						mentions(teks, mentioned, true)
						lorien.groupRemove(from, mentioned)
					} else {
						mentions(`_*O trouxa levou bankkk XD*_ : @${mentioned[0].split('@')[0]}`, mentioned, true)
						lorien.groupRemove(from, mentioned)
					}
					break
				case 'listadmins':
				case 'adminslist':
				case 'admins':				
					if (!isGroup) return reply(mess.only.group)
					teks = `_*Lista de admins do grupo :*_*\n\n${groupMetadata.subject}*\n\n_*Total :*_ ${groupAdmins.length}\n\n`
					no = 0
					for (let admon of groupAdmins) {
						no += 1
						teks += `[${no.toString()}] @${admon.split('@')[0]}\n`
					}
					mentions(teks, groupAdmins, true)
					break
                                case 'linkgp':
                                        if (!isGroup) return reply(mess.only.group)
                                        if (!isGroupAdmins) return reply(mess.only.admin)
                                        if (!isBotGroupAdmins) return reply(mess.only.Badmin)
                                        linkgc = await lorien.groupInviteCode(from)
                                        reply('https://chat.whatsapp.com/'+linkgc)
                                        break
                                case 'kitar':
                                        if (!isGroup) return reply(mess.only.group)
                                        if (isGroupAdmins || is) {
                                            lorien.groupLeave(from)
                                        } else {
                                            reply(mess.only.admin)
                                        }
                                        break                                     
				case 'toimg':
				if (!isGroup) return reply(mess.only.group)
					if (!isQuotedSticker) return reply('_*responda uma figurinha*_')
					reply(mess.wait)
					encmedia = JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo
					media = await lorien.downloadAndSaveMediaMessage(encmedia)
					ran = getRandom('.png')
					exec(`ffmpeg -i ${media} ${ran}`, (err) => {
						fs.unlinkSync(media)
						if (err) return reply('_*Este comando so converte figurinhas que sao imagens*_')
						buffer = fs.readFileSync(ran)
						lorien.sendMessage(from, buffer, image, {quoted: mek, caption: '_*Ta aqui sua imagem*_'})
						fs.unlinkSync(ran)
					})
					break
				case 'welcome':
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (args.length < 1) return reply('_*1 para ativar, 0 para desativar*_')
					if (Number(args[0]) === 1) {
						if (isWelkom) return reply('_*Ja ativo*_')
						welkom.push(from)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('_*Ativo o recurso de boas-vindas neste grupo*_')
					} else if (Number(args[0]) === 0) {
						welkom.splice(from, 1)
						fs.writeFileSync('./src/welkom.json', JSON.stringify(welkom))
						reply('_*Desativou o recurso de boas-vindas neste grupo*_')
					} else {
						reply('_*1 para ativar, 0 para desativar*_')
					}
                                      break
				case 'clone':
					if (!isGroup) return reply(mess.only.group)
					if (!isOwner) return reply(mess.only.B)
					if (args.length < 1) return reply('_*A tag da pessoa que voce deseja clonar a foto*_')
					if (mek.message.extendedTextMessage === undefined || mek.message.extendedTextMessage === null) return reply('marque uma pessoa para clonar a foto de perfil')
					mentioned = mek.message.extendedTextMessage.contextInfo.mentionedJid[0]
					let { jid, id, notify } = groupMembers.find(x => x.jid === mentioned)
					try {
						pp = await lorien.getProfilePicture(id)
						buffer = await getBuffer(pp)
						lorien.updateProfilePicture(botNumber, buffer)
						mentions(`_*Roubei a foto de perfil do :*_ @${id.split('@')[0]}`, [jid], true)
					} catch (e) {
						reply('falhou')
					}
					break
					case 'fechargp':
	
			lorien.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					var nomor = mek.participant
					const close = {
					text: `_*O GRUPO FOI FECHADO POR :*_ @${nomor.split("@s.whatsapp.net")[0]}\n\n_*APENAS ADMS PODEM MANDAR MENSAGENS*_`,
					contextInfo: { mentionedJid: [nomor] }
					}
					lorien.groupSettingChange (from, GroupSettingChange.messageSend, true);
					reply(close)
					break
                case 'abrirgp':
					lorien.updatePresence(from, Presence.composing) 
					if (!isGroup) return reply(mess.only.group)
					if (!isGroupAdmins) return reply(mess.only.admin)
					if (!isBotGroupAdmins) return reply(mess.only.Badmin)
					open = {
					text: `_*O GRUPO FOI ABERTO POR :*_ @${sender.split("@")[0]}\n\n_*TODOS OS MEMBROS PODEM MANDAR MENSAGENS*_`,
					contextInfo: { mentionedJid: [sender] }
					}
					lorien.groupSettingChange (from, GroupSettingChange.messageSend, false)
					lorien.sendMessage(from, open, text, {quoted: mek})
					break
					case 'setname':
     if (!isGroup) return reply(ind.groupo())
			  if (!isGroupAdmins) return reply(ind.admin())
	 	  if (!isBotGroupAdmins) return reply(ind.badmin())
     lorien.groupUpdateSubject(from, `${body.slice(9)}`)
     lorien.sendMessage(from, '_*NOME DO GRUPO ALTERADO COM SUCESSO*_', text, {quoted: mek})
     break
					case 'tm':
					lorien.updatePresence(from, Presence.composing) 
					if (!isOwner) return reply(mess.only.ownerG)
					if (args.length < 1) return reply('.......')
					anu = await lorien.chats.all()
					if (isMedia && !mek.message.videoMessage || isQuotedImage) {
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						buff = await lorien.downloadMediaMessage(encmedia)
						for (let _ of anu) {
							lorien.sendMessage(_.jid, buff, image, {caption: `*[ TRANSMISSAO ]*\n\n${body.slice(4)}`})
						}
						reply('')
					} else {
						for (let _ of anu) {
							sendMess(_.jid, `*[ Transmissao de aviso ]*\n\n${body.slice(4)}`)
						}
						reply('TRANSMISSAO FEITA')
					}
					break
					case 'feiura':
					if (!isGroup) return reply(mess.only.group)
              lorien.updatePresence(from, Presence.composing) 
                random = `${Math.floor(Math.random() * 100)}`
               hasil = `_*Seu nivel de feiurakkk :*_ \n\n_*Voce e :*_ *${random}%* _*Feiokkk*_`
              reply(hasil)
                break
					case 'gado':
					if (!isGroup) return reply(mess.only.group)
              lorien.updatePresence(from, Presence.composing) 
                random = `${Math.floor(Math.random() * 100)}`
               hasil = `_*Seu nivel de gadisse :*_ \n\n_*voce e :*_ *${random}%* _*gadokkk*_`
              reply(hasil)
                break
				case 'wait':
				if (!isGroup) return reply(mess.only.group)
					if ((isMedia && !mek.message.videoMessage || isQuotedImage) && args.length == 0) {
						reply(mess.wait)
						const encmedia = isQuotedImage ? JSON.parse(JSON.stringify(mek).replace('quotedM','m')).message.extendedTextMessage.contextInfo : mek
						media = await lorien.downloadMediaMessage(encmedia)
						await wait(media).then(res => {
							lorien.sendMessage(from, res.video, video, {quoted: mek, caption: res.teks.trim()})
						}).catch(err => {
							reply(err)
						})
					} else {
						reply('_*mande uma foto  com o comando para ter resultados*_')
					}
					break
 				default:
					if (isGroup && isSimi && budy != undefined) {
						console.log(budy)
						muehe = await simih(budy)
						console.log(muehe)
						reply(muehe)
					} else {
						console.log(color('[ERROR]','red'), 'Comando nao registrado de : ', color(sender.split('@')[0]))
					}
                           }
		} catch (e) {
			console.log('Error : %s', color(e, 'red'))
		}
	})
}
starts()

